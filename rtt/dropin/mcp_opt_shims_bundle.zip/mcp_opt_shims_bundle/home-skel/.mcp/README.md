Caches and flags only. No secrets.
