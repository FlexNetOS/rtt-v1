# MCP /opt Shims + Home Layout + Gatekeeper
Purpose: eliminate global installs and force digest‑pinned tool execution.
