# RTT + MCP Drop-in (no-dup agents)

Single source of truth for agents under `agents/common`. Project them into provider trees like `providers/claude/.claude/agents` without duplication.

## Quick start
1. Project providers:
   ```bash
   python tools/project_providers.py
   ```
2. Optional: import MCP tool list to RTT manifests:
   ```bash
   python connector-mcp/mcp_to_rtt.py claude providers/claude/.claude/tools.json
   ```
3. Wire routes:
   ```bash
   rtt scan && rtt plan && rtt apply
   ```

Folders:
- `.rtt/` panel, policy, routes, manifests, linkmap
- `agents/common/` canonical agent manifests
- `providers/*/.<provider>/agents` symlinks or proxy refs
- `connector-mcp/` bridge and generator
- `tools/project_providers.py` no-dup projection
