# MCP + Skills ingest and invariant-gated plan builder

## Commands
```bash
# 0) Generate signer keys
python tools/keys_ed25519.py dev-ed25519

# 1) Ingest canonical agents
python tools/agents_ingest.py agents/common/*.agent.json

# 2) Ingest MCP tools → CAS + RTT manifests
python tools/mcp_ingest.py claude mcp/claude/tools.json

# 3) Ingest skills
python tools/skills_ingest.py skills/*.skill.json

# 4) Build signed plan with autowire and invariants gate
python tools/plan_build.py .rtt/routes.json .rtt/manifests dev-ed25519 agents/common claude skills --autowire

# 5) Verify plan
python tools/plan_verify.py plans/latest.json
```
Notes:
- Autowire connects agent.id to MCP tool.name, and also maps skill capabilities.
- Invariant gate refuses plan if endpoints are missing, duplicated, or self-looped.
- Extend skills schema with richer matches when needed.
