export RTT_HOME="$HOME/.rtt"
