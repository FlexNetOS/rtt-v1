Expect local llama.cpp binary as `./llama_cli` symlink. Scripts will call it if present.
