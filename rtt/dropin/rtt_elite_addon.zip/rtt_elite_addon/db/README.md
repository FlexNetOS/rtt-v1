# DB connectors placement
SQLite (embedded, RTT), Postgres (Both), Neo4j (Both), Redis (RTT), Qdrant (Both), Kong (RTT), Prometheus (RTT exporter).
