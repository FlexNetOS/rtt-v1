# System layout mapping
systemd user unit in `systemd/`; drivers in `.rtt/drivers/`; index in `rtt_elite_addon/index/`; wal in `.rtt/wal/`; binaries in `.rtt/bin/`.
