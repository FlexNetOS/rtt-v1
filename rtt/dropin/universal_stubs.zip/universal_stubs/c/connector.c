#include <stdio.h>
int main(){ puts("{\"id\":\"0\",\"result\":{\"ok\":true},\"error\":null}"); return 0; }
