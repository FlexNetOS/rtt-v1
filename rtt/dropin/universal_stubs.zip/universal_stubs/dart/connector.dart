import 'dart:io';
void main() { stdin.readLineSync(); print('{"id":"0","result":{"ok":true},"error":null}'); }
