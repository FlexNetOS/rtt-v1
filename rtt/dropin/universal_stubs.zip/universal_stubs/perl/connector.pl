#!/usr/bin/env perl
use strict; use warnings;
my $line = <>;
print "{"id":"0","result":{"ok":true},"error":null}\n";
