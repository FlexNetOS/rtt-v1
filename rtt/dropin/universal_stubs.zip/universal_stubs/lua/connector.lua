#!/usr/bin/env lua
local line = io.read()
print('{"id":"0","result":{"ok":true},"error":null}')
