# PowerShell stdio echo
$line = [Console]::In.ReadLine()
Write-Output '{"id":"0","result":{"ok":true},"error":null}'
