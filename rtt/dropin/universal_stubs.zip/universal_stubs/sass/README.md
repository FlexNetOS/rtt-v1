# sass stub
Not a primary runtime for connectors. Use a runnable stub in a nearby language and bind via RTT manifests.