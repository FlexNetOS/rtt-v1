#!/usr/bin/env bash
# Reads one JSON line and echos a static JSON response
read line
echo '{"id":"0","result":{"ok":true},"error":null}'
