public class Connector{ public static void main(String[]args)throws Exception{ System.out.println("{\"id\":\"0\",\"result\":{\"ok\":true},\"error\":null}"); } }
