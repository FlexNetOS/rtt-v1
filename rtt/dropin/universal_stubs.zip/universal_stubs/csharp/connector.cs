using System;
class Connector{ static void Main(){ Console.WriteLine("{\"id\":\"0\",\"result\":{\"ok\":true},\"error\":null}"); } }
