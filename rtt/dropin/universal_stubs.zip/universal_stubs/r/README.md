# r connector stub
Run from stdin, output JSON response.
