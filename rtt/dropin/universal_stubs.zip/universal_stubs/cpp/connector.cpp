#include <iostream>
int main(){ std::cout << "{\"id\":\"0\",\"result\":{\"ok\":true},\"error\":null}\n"; }
