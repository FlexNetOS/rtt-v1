// cargo new connector && replace main.rs
fn main(){ println!(r#"{{"id":"0","result":{{"ok":true}},"error":null}}"#); }
