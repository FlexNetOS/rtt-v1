fun main(){ println("{\"id\":\"0\",\"result\":{\"ok\":true},\"error\":null}") }
