import Foundation
print("{\"id\":\"0\",\"result\":{\"ok\":true},\"error\":null}")
