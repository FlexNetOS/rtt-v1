#!/usr/bin/env php
<?php
$line = trim(fgets(STDIN));
echo json_encode(["id"=>"0","result"=>["ok"=>true],"error"=>null])."\n";
