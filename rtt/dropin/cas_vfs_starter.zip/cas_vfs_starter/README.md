# CAS + VFS Starter

Single source of truth via CAS. Provider views materialized without duplication. Ready to feed RTT.

## Steps
1) Ingest canonical agents into CAS:
```bash
python tools/cas_ingest.py agents/common/*.agent.json
```
2) Build packfile and LUT:
```bash
python tools/cas_pack.py
```
3) Materialize provider view (no FUSE yet):
```bash
python tools/view_materialize.py views/claude.view.json
```
4) Export RTT manifests from realized agents:
```bash
python tools/view_to_rtt.py providers/claude/.claude/agents/*.agent.json
```

## Files
- `.rtt/registry/cas/sha256/<hash>.json` — immutable canonical entries
- `.rtt/registry/pack/agents.pack` and `index.lut` — memory-mappable pack
- `overlays/` — provider and env overlays
- `views/*.view.json` — signed view plans (signature placeholder)
- `providers/<prov>/.<prov>/agents/` — materialized view
- `.rtt/manifests/` — generated RTT manifests

## Replace later
- FUSE/WinFsp daemon for real VFS.
- Real Ed25519 signing and verification.
- Constraint planner and signed route plans.
