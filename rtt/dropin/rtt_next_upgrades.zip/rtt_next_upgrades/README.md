# RTT Next Upgrades

This scaffold adds:
- Real VFS path (FUSE skeleton). Use WinFsp on Windows.
- Ed25519 sign/verify CLIs (Rust + Go).
- Planner stub that emits signed plans.
- Driver stubs (Rust, Python, Go, Node) via JSON-over-stdio.
- SHM ring crate skeleton.
- JS/TS/PNPM workspace config.

## Build order
1. rtt-sign (Rust) → generate keys and sign plans.
2. rtt-planner (Rust) → emit plans/<hash>.json and sign with rtt-sign.
3. rtt-viewfs (Rust) → mount providers path from CAS.
4. Drivers → implement Probe/Open/Tx/Rx/Close/Health.
5. rtt-fabric-shm → implement SPSC ring hot path.

## Commands
cargo build -p rtt-sign --release
cargo build -p rtt-planner --release
cargo run -p rtt-planner -- routes.json .rtt/manifests plans/0001.json <priv_b64>
node drivers/node/connector-file/index.js  # example driver run
