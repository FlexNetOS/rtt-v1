module.exports = {
  hooks: {
    readPackage(pkg) {
      // Example: pin or rewrite deps here if needed.
      return pkg;
    }
  }
}
