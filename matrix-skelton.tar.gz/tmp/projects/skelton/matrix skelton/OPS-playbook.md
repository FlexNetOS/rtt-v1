---
title: "OPS Playbook"
date: 2024-06-10
draft: true
tags: ["ops", "playbook", "rtt", "mcp"]
---
# OPS Playbook
This playbook outlines the operational steps and best practices for managing the dev-playground environment, including vendor pinning, CI/CD processes, observability, policy enforcement, documentation, and release strategies.

Answer: adopt the **2×2 matrix** and keep each quadrant independently operable. Run **RTT** in all quadrants. Run **MCP-Edge** in all quadrants and a **single MCP-Core** for signing, policy authorship, and audit. Promotions are **monotone moves** in the matrix with upgrade-only guards.

Below is the full PRD addendum and the kustomize set to label a single cluster into the four quadrants.

# PRD Addendum — Agentic Matrix (2×2) with RTT + MCP

## 0) Goal

Deliver an autonomous, upgrade-only platform with zero human ops, zero global installs, and plane-independent failover. Matrix axes:

* **Row (Environment):** `dev` vs `prod`
* **Column (Governance):** `experimental` vs `governed`

Quadrants:
DX = Dev-Experimental, DG = Dev-Governed, PX = Prod-Experimental, PG = Prod-Governed.

## 1) Roles by Quadrant

| Quadrant | Primary purpose          | RTT role                                             | MCP role                                                         | Event fabric              | Identity                          |
| -------- | ------------------------ | ---------------------------------------------------- | ---------------------------------------------------------------- | ------------------------- | --------------------------------- |
| **DX**   | Explore, generate, learn | Run APO, emulators, symbol extraction, test adapters | MCP-Edge with OPA dry-run; local policy mirror; signing disabled | Local NATS+JetStream, DLQ | SPIRE domain `dx.local` federates |
| **DG**   | Harden artifacts         | Repro builds, schema coercion tests, SBOM            | MCP-Edge enforce; provenance assemble; pre-sign checks           | Local NATS+JS             | SPIRE `dg.local` federates        |
| **PX**   | Shadow + canary in prod  | Route controlled traffic; measure cost/SLO           | Enforce budgets/flags; rollout hints                             | Local NATS+JS             | SPIRE `px.local` federates        |
| **PG**   | Steady prod (blue/green) | Gateway, agents, adapters, WASM                      | Enforce strict OPA/GK; audit; rollout commits                    | Local NATS+JS             | SPIRE `pg.local` federates        |

**MCP-Core** (singleton, can be HA): policy authorship, key custody (t-of-n), transparency log, cross-quadrant audits.

## 2) Upgrade-only lattice and moves

* Allowed moves: **DX → DG → PX → PG** and **shadow PG → canary PX → PG**.
* Emergency rollback requires *break-glass* with time-boxed cert and quorum record.
* Every move checks: invariants, budgets, residency, attestation hash, provider safety.

## 3) Contracts and “secret” levers

* **Content-address everything.** Tools only from `/opt/mcp/<pkg>@sha256:<digest>` via `mcp-shim`.
* **Typed IO.** JSON-Schema on every tool; inline coercion via **WASM filters**.
* **Budget as a resource.** Token buckets on dollars, tokens, and latency; admission fails when spent.
* **Shadow-first.** PX always records deltas before canary.
* **Graph routing.** Neo4j symbol↔tool↔data graph drives planning and prewarm.
* **Churn control.** Cap daily rollout churn to reduce tail risk and cache invalidation.
* **Federated identity.** One SPIRE per quadrant; trust bundles federated; deny-by-default.
* **Event truth.** Signed CloudEvents with Ed25519; Rekor-like transparency log.

## 4) Core subsystems

### Identity and transport

* SPIRE per quadrant (`spiffe://<quad>.local`). Federation: MCP-Core trusts all bundles.
* All hops mTLS: Envoy h2c→mTLS to gateway; NATS with SVID certs.

### Policy

* **OPA bundles**: `plan_invariants.rego`, `schema_coercion.rego`, `provider_safety.rego`, `budgets.rego`.
* **Gatekeeper**: forbid `/opt/mcp/current`; require digest annotations; pin image digests; residency labels.

### Event fabric

* NATS+JetStream **per quadrant**. Leafnode bridges when links are up. Subjects: `mcp.events`, `mcp.rollouts`, `mcp.usage`, `dlq.*`.

### Artifact stores

* Global CAS (object storage) + per-quadrant read-through cache.
* SBOM + provenance kept in DG; signed by MCP-Core.

### Observability

* OTel GenAI spans: tokens, cost, latency, model, provider, decision path; budget correlation.
* SLO dashboards per quadrant; PX/PG side-by-side charts.

### Data & adapters

* Postgres for control; SQLite for DX; Neo4j for graph; Qdrant for vectors; adapters shipped as MCP servers, pinned by digest.

## 5) Autonomy loop

1. **Discover (DX)**: APO scans drop-ins, extracts symbols, drafts tools and schemas.
2. **Prove (DG)**: SBOM, attestation, coercion tests, provider safety.
3. **Plan (DG)**: solver builds plan with budgets; AdmissionSim runs.
4. **Shadow (PX)**: limited traffic; cost and SLO measured; violations → DLQ.
5. **Promote (PG)**: Argo Rollouts weight via OpenFeature; upgrade-only acceptance.
6. **Observe (PG)**: OTel feeds optimizer; churn within bounds; auto self-heal.

## 6) Zero installs and FS layout

* `/usr/bin`: only shims.
* `/opt/mcp/<pkg>@<digest>`: read-only bundles.
* `/var/lib/mcp`: CAS index, graph cache.
* `~/.mcp`: flags, caches, aliases; *no secrets*.
* `/tmp`: tmpfs with caps, scrubbed; WASM scratch.

## 7) Failure and takeover

* Anycast/GSLB in front of PG+PX; if PG fails, PX can assume; if both fail, DG can run readied artifacts using same plan hash.
* Each quadrant can operate **solo** with its MCP-Edge and local policies. Federation only enhances, never blocks.

## 8) UI/UX

* Matrix board (2×2): tile per quadrant with readiness, plan hash, policy rev, budget, flags, SLO, warm-pool state.
* One-click “Promote to next cell” guarded by invariants.
* Plan diff, OPA decision view, trace links, cost and residency map.

## 9) Open questions

* Threshold signing split across Core vs quadrants.
* Formal churn limits per tenant.
* Learned placement vs rule-based for first release.

---

# Kustomize — Single Cluster Labeled into Four Quadrants

> Layout: one Kubernetes cluster. Four namespaces with labels: `env=dev|prod`, `gov=experimental|governed`. Quadrant-local NATS, OPA, Gatekeeper constraints, and flags. SPIRE server per quadrant or one server with per-ns trust domains (simpler to demo).

```
repo/
└─ kustomize/
   ├─ base/
   │  ├─ namespaces.yaml
   │  ├─ nats.yaml
   │  ├─ openfeature-flags-cm.yaml
   │  ├─ opa.yaml
   │  ├─ gatekeeper-constraints.yaml
   │  ├─ spire-server.yaml
   │  ├─ spire-agent-daemonset.yaml
   │  ├─ otel-collector.yaml
   │  ├─ gateway-deploy.yaml
   │  └─ kustomization.yaml
   ├─ overlays/
   │  ├─ dev-experimental/
   │  │  └─ kustomization.yaml
   │  ├─ dev-governed/
   │  │  └─ kustomization.yaml
   │  ├─ prod-experimental/
   │  │  └─ kustomization.yaml
   │  └─ prod-governed/
   │     └─ kustomization.yaml
   └─ matrix/
      └─ kustomization.yaml   # composes all four overlays
```

## base/namespaces.yaml

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: dx
  labels: { env: dev, gov: experimental, quad: dx }
---
apiVersion: v1
kind: Namespace
metadata:
  name: dg
  labels: { env: dev, gov: governed, quad: dg }
---
apiVersion: v1
kind: Namespace
metadata:
  name: px
  labels: { env: prod, gov: experimental, quad: px }
---
apiVersion: v1
kind: Namespace
metadata:
  name: pg
  labels: { env: prod, gov: governed, quad: pg }
```

## base/nats.yaml (one per namespace; JetStream on)

```yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: nats-conf, namespace: PLACEHOLDER_NS }
data:
  nats.conf: |
    jetstream: { max_mem: 1Gb, max_file: 10Gb }
    port: 4222
    tls {
      cert_file: /var/run/spire/svid.pem
      key_file: /var/run/spire/key.pem
      ca_file: /var/run/spire/bundle.pem
      verify: true
    }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: nats, namespace: PLACEHOLDER_NS }
spec:
  replicas: 1
  selector: { matchLabels: { app: nats } }
  template:
    metadata: { labels: { app: nats } }
    spec:
      volumes:
        - name: nats-conf
          configMap: { name: nats-conf }
        - name: spire-svid
          projected:
            sources:
              - serviceAccountToken: { path: "token", audience: "spire" }
      containers:
        - name: nats
          image: nats:2.10
          args: ["-c","/etc/nats/nats.conf","-js"]
          volumeMounts:
            - name: nats-conf
              mountPath: /etc/nats
            - name: spire-svid
              mountPath: /var/run/spire
              readOnly: true
          ports: [{containerPort: 4222}]
```

> In overlays below, replace `PLACEHOLDER_NS` per quadrant and add leafnode/mirror when inter-linking.

## base/openfeature-flags-cm.yaml

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: openfeature-flags
  namespace: PLACEHOLDER_NS
data:
  flags.json: |
    {
      "plan.canaryWeight": { "variants": { "off": 0, "low": 10, "high": 50 }, "defaultVariant": "off" },
      "gateway.safeMode": { "variants": { "off": false, "on": true }, "defaultVariant": "off" }
    }
```

## base/opa.yaml (OPA server with bundle pointer)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: opa, namespace: PLACEHOLDER_NS }
spec:
  replicas: 1
  selector: { matchLabels: { app: opa } }
  template:
    metadata: { labels: { app: opa } }
    spec:
      containers:
        - name: opa
          image: openpolicyagent/opa:0.64.0
          args: ["run","--server","--addr=0.0.0.0:8181","--set=bundle.service.url=$(BUNDLE_URL)"]
          env:
            - name: BUNDLE_URL
              value: "https://mcp-core.example/bundles/v2"   # per quadrant mirror OK
          ports: [{containerPort: 8181}]
```

## base/gatekeeper-constraints.yaml (digest pins + forbid `/opt/mcp/current`)

```yaml
apiVersion: constraints.gatekeeper.sh/v1beta1
kind: K8sForbidCurrentOpt
metadata: { name: forbid-current-opt, namespace: PLACEHOLDER_NS }
spec:
  match: { kinds: [ { apiGroups: ["apps"], kinds: ["Deployment"] } ], namespaces: ["PLACEHOLDER_NS"] }
---
apiVersion: constraints.gatekeeper.sh/v1beta1
kind: K8sRequireDigests
metadata: { name: require-opt-digests, namespace: PLACEHOLDER_NS }
spec:
  match: { kinds: [ { apiGroups: ["apps"], kinds: ["Deployment"] } ], namespaces: ["PLACEHOLDER_NS"] }
  parameters: { annotation: "rtt.opt/digests" }
```

> The corresponding `ConstraintTemplate`s ship once cluster-wide (already provided in your gatekeeper chart).

## base/spire-server.yaml (sketch)

```yaml
apiVersion: spire.spiffe.io/v1alpha1
kind: Server
metadata: { name: spire-server, namespace: PLACEHOLDER_NS }
spec:
  trustDomain: PLACEHOLDER_NS.local
```

## base/spire-agent-daemonset.yaml (sketch)

```yaml
apiVersion: spire.spiffe.io/v1alpha1
kind: Agent
metadata: { name: spire-agent, namespace: PLACEHOLDER_NS }
spec:
  serverAddress: spire-server.PLACEHOLDER_NS:8081
```

## base/otel-collector.yaml (GenAI spans)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: otel-collector, namespace: PLACEHOLDER_NS }
spec:
  replicas: 1
  selector: { matchLabels: { app: otel-collector } }
  template:
    metadata: { labels: { app: otel-collector } }
    spec:
      containers:
        - name: otel
          image: otel/opentelemetry-collector:0.103.0
          args: ["--config=/etc/otel/config.yaml"]
          volumeMounts:
            - name: cfg
              mountPath: /etc/otel
      volumes:
        - name: cfg
          configMap:
            name: otel-config
---
apiVersion: v1
kind: ConfigMap
metadata: { name: otel-config, namespace: PLACEHOLDER_NS }
data:
  config.yaml: |
    receivers: { otlp: { protocols: { grpc: {}, http: {} } } }
    processors: { batch: {}, attributes: {} }
    exporters: { otlp: { endpoint: "otel-backend.pg.svc:4317", tls: { insecure: true } } }
    service:
      pipelines:
        traces: { receivers: [otlp], processors: [batch], exporters: [otlp] }
```

## base/gateway-deploy.yaml (flags + shims + OPA)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: model-gateway
  namespace: PLACEHOLDER_NS
  labels: { app: model-gateway }
spec:
  replicas: 2
  selector: { matchLabels: { app: model-gateway } }
  template:
    metadata:
      labels: { app: model-gateway }
      annotations:
        rtt.opt/digests: "7b1c...c0a9, 9e3f...12ab"
    spec:
      containers:
        - name: gw
          image: ghcr.io/yourorg/model-gateway@sha256:abcdef...   # digest only
          env:
            - { name: MCP_PLAN_BIN, value: "/opt/mcp/node@sha256:7b1c.../bin:/opt/mcp/claude-flow@sha256:9e3f.../bin" }
            - { name: MCP_VERIFY_DIGEST, value: "1" }
            - { name: OPENFEATURE_FLAG_FILE, value: "/flags/flags.json" }
            - { name: OPA_URL, value: "http://opa.PLACEHOLDER_NS.svc:8181" }
            - { name: NATS_URL, value: "nats://nats.PLACEHOLDER_NS.svc:4222" }
          volumeMounts:
            - { name: flags, mountPath: /flags, readOnly: true }
          ports: [{ containerPort: 8080 }]
      volumes:
        - name: flags
          configMap: { name: openfeature-flags }
```

## base/kustomization.yaml

```yaml
resources:
  - namespaces.yaml
  - nats.yaml
  - openfeature-flags-cm.yaml
  - opa.yaml
  - gatekeeper-constraints.yaml
  - spire-server.yaml
  - spire-agent-daemonset.yaml
  - otel-collector.yaml
  - gateway-deploy.yaml
commonAnnotations:
  managed-by: agentic-matrix
```

## overlays/dev-experimental/kustomization.yaml

```yaml
namespace: dx
nameSuffix: -dx
resources:
  - ../../base
patches:
  - target: { kind: ConfigMap, name: nats-conf }
    patch: |-
      - op: replace
        path: /metadata/namespace
        value: dx
  - target: { kind: Deployment, name: nats }
    patch: |-
      - op: replace
        path: /metadata/namespace
        value: dx
# repeat simple namespace replacements for other base resources or use kustomize vars
```

> Create similar overlays for `dg`, `px`, and `pg`, or use kustomize `replacements` to map `PLACEHOLDER_NS`.

## matrix/kustomization.yaml

```yaml
resources:
  - ../overlays/dev-experimental
  - ../overlays/dev-governed
  - ../overlays/prod-experimental
  - ../overlays/prod-governed
```

---

# Ops playbook summary

* **Per quadrant**: NATS+JetStream; OPA; Gatekeeper constraints; SPIRE; OTel collector; flags ConfigMap; model gateway Deployment with digest pins and shims.
* **Leaf bridging**: optionally bridge NATS between PX↔PG for shadow; disable for isolation drills.
* **Promotion**: DX→DG signs at Core; DG publishes plan; PX shadows; PG promotes via Argo Rollouts or OpenFeature weight with OPA gate.
* **Failover**: health flips anycast to PX, then DG; same plan hash and policy rev.
* **DLQ**: watcher per quadrant alerts Slack/PagerDuty.

This covers the matrix structure, independence, RTT/MCP placement, policies, identity, event fabric, autonomy loop, and a concrete kustomize scaffold to stamp a single cluster into all four quadrants.
---
Missing pieces and high-leverage upgrades:

# Governance & supply chain

* Threshold signing with HSMs. t-of-n for plan attestation; automated key rotation; Rekor transparency log anchoring.
* Hermetic, reproducible builds. Nix/Bazel + SLSA L3+ provenance; SBOM generation and vuln gating per bundle.
* License compliance gates. Automated SPDX scanning and policy exceptions.

# Identity & secrets

* SPIRE federation hardening. Per-quadrant trust bundles with rotation and break-glass certs that self-revoke.
* Secret flow design. Envelope encryption, per-tenant DEK rotation, access proofs in audit trail.

# Data governance

* PII catalog + residency map. Column-level tags, dataset lineage in the graph, deny-by-construction routes.
* Right-to-erasure and retention. TTL plus cryptographic erasure for all stores and backups.

# Eventing & contracts

* Schema registry. Versioned JSON-Schema/Avro for CloudEvents; compat checks in CI; graceful downgrade shims.
* Message QoS & backpressure. JetStream consumer groups, rate limiters, circuit breakers, idempotency keys.

# Observability & SLOs

* Long-term trace storage. Exemplars linking traces ↔ metrics; redaction at source; privacy budgets.
* SLO autopilot. Error-budget policies that gate promotion and trigger rollback without humans.

# Reliability & DR

* RPO/RTO tested restores. Periodic fire-drills for CAS, graph, Postgres, and vector stores; cross-quadrant warm standby.
* Anycast/GSLB runbooks. Health calculators that include budget and latency, not only liveness.

# Performance & latency

* Prompt/result caches. KV + embedding cache with TTL and eviction; locality-aware routing.
* GPU/MPS/MIG scheduling. Resource classes for model lanes; NUMA/cgroup pinning for SHM/UDS lanes.
* Realtime lane QoS. TURN pool sizing, QUIC prioritization, jitter buffers.

# Safety & model quality

* Eval harness with golden sets. Jailbreak and prompt-injection tests; structured-output accuracy gates.
* Tool sandboxing. Seccomp/landlock profiles for tools; filesystem caps for adapters.
* DP and redaction. Differential-privacy budgets for logging and analytics exports.

# Multi-tenancy & cost

* Hard quotas and budgets.rego. Per-tenant token, $ and latency buckets enforced at admission and per hop.
* Cost attribution. Span-level costing rolled up to tenants, features, and plans; anomaly detection.

# UI/UX workflow

* Policy what-if simulator. Show which invariant blocks a plan and how to satisfy it.
* Plan replay and diff. Deterministic re-runs from CAS; visual tool/flag deltas between revisions.

# Tooling & SDKs

* Formal plugin ABI. Versioned MCP tool contracts; stubs for all listed languages; conformance tests.
* CLI. `agenticctl` for plan lint, sign, admit, shadow, promote, rollback, and drift fix.

# Deploy/IaC

* Terraform/Crossplane modules. One-button quadrant stamp with SPIRE, NATS, OPA, Gatekeeper, OTel, flags.
* GitOps policies. Mandatory PR approvals for governed column; auto-merge in experimental with guardrails.

# Edge & homelab

* Offline mode. Local CAS mirror + policy snapshot; delayed reconciliation when links return.
* Package formats. DEB/RPM/MSI/PKG with FHS layout; Windows WinFsp VFS driver.

# Testing & chaos

* Chaos suites. NATS partitions, SPIRE outage, OPA timeouts, provider brownouts; verify autonomous recovery.
* Soak tests. Long-haul workloads to detect churn and memory regressions.

# Compliance

* SOC2/HIPAA/GDPR mappings. Control annotations on plans; automated evidence collection.

# Formal methods

* Upgrade-only proof. TLA+/Ivy spec for the lattice and promotion protocol; model-checked invariants.

If you want these wired now, say “proceed” and I’ll collapse into the one-page PRD addendum and produce the kustomize overlays for the four quadrants.
---
Proceeding with the collapse. Keep the 2×2 matrix, upgrade-only lattice, and independence per quadrant.

# PRD Addendum — Agentic Matrix (2×2) with RTT + MCP

**Goal.** Autonomous, upgrade-only platform with failover across quadrants. Zero global installs. Content-addressed bundles. Signed CloudEvents. SPIRE mTLS everywhere.

**Axes.** Row: `dev|prod`. Column: `experimental|governed`. Quadrants: **DX** (dev+exp), **DG** (dev+gov), **PX** (prod+exp), **PG** (prod+gov).

**Roles.**

* **RTT**: runs in all quadrants. Execution lanes (SHM/UDS/QUIC), WASM filters, adapters.
* **MCP-Edge**: in all quadrants. OPA enforce/dry-run, OpenFeature flags, NATS+JetStream, budgets, DLQ.
* **MCP-Core**: singleton for policy authorship, threshold signing, transparency log, cross-quadrant audit.

**Contracts.**

* Tools only via `/opt/mcp/<pkg>@sha256:<digest>`; `/usr/bin` shims; Gatekeeper forbids `/opt/mcp/current`.
* JSON-Schema on every tool I/O; inline coercion via WASM; schema registry for CloudEvents.
* Budgets as resources (tokens, $, latency). Admission denies when exhausted.
* SPIRE trust domains per quadrant; federation enabled; deny-by-default.
* OTel GenAI spans: model, provider, tokens, cost, SLO tags.

**Promotion protocol (monotone).**

```
DX → DG → PX → PG
```

* DX: discover, synthesize stubs, draft schemas.
* DG: SBOM, provenance, policy dry-run, sign. Output = plan@hash + attestation.
* PX: shadow+canary under budgets; record deltas. Violations → DLQ.
* PG: blue/green via OpenFeature weight or Rollouts. Auto-rollback on SLO breach.
* All moves check: invariants, provider safety, residency, budget, attestation hash match.

**Independence & failover.**

* Each quadrant has its own RTT, MCP-Edge, OPA, NATS, flags, SPIRE. CAS is global with RO caches.
* Anycast/GSLB fronts PG+PX; takeover order PG→PX→DG. Same plan hash + bundle rev = zero rebuild.
* Quorum rollouts: ≥2 quadrants sign promotion (optional but recommended).

**Observability.**

* OTel collector per quadrant; exemplars link traces↔metrics↔cost.
* JetStream retries, DLQ subject with Slack/PagerDuty alerts.

**Data governance.**

* Dataset residency map; PII tags; provider safety policy. Cryptographic erasure + retention TTLs.

**SLOs (defaults).**

* P50 latency: route chooses local SHM/UDS, QUIC fallback. P99 budget caps canary.
* Error budget policy gates promotions. Cost ceilings enforced at admission.

**Non-goals (v1).**

* Cross-quadrant stateful DB failover. Keep DBs per quadrant, replicate read-only where needed.

---

# Kustomize — Label a Single Cluster into Four Quadrants

> Creates four namespaces with matrix labels and ready slots for quadrant-local components. Keep cluster-wide Gatekeeper **ConstraintTemplates** installed once. Apply quadrant-scoped **Constraints** separately if desired.

## `kustomize/base/namespaces.yaml`

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: dx
  labels: { env: dev, gov: experimental, quad: dx }
---
apiVersion: v1
kind: Namespace
metadata:
  name: dg
  labels: { env: dev, gov: governed, quad: dg }
---
apiVersion: v1
kind: Namespace
metadata:
  name: px
  labels: { env: prod, gov: experimental, quad: px }
---
apiVersion: v1
kind: Namespace
metadata:
  name: pg
  labels: { env: prod, gov: governed, quad: pg }
```

## `kustomize/base/flags-configmap.yaml`

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: openfeature-flags
  namespace: PLACEHOLDER_NS
data:
  flags.json: |
    {
      "plan.canaryWeight": { "variants": { "off": 0, "low": 10, "high": 50 }, "defaultVariant": "off" },
      "gateway.safeMode": { "variants": { "off": false, "on": true }, "defaultVariant": "off" }
    }
```

## `kustomize/base/gatekeeper-constraints.yaml`  *(quadrant-scoped)*

```yaml
apiVersion: constraints.gatekeeper.sh/v1beta1
kind: K8sForbidCurrentOpt
metadata: { name: forbid-current-opt, namespace: PLACEHOLDER_NS }
spec:
  match: { kinds: [ { apiGroups: ["apps"], kinds: ["Deployment"] } ], namespaces: ["PLACEHOLDER_NS"] }
---
apiVersion: constraints.gatekeeper.sh/v1beta1
kind: K8sRequireDigests
metadata: { name: require-opt-digests, namespace: PLACEHOLDER_NS }
spec:
  match: { kinds: [ { apiGroups: ["apps"], kinds: ["Deployment"] } ], namespaces: ["PLACEHOLDER_NS"] }
  parameters: { annotation: "rtt.opt/digests" }
```

## `kustomize/base/gateway-deploy.yaml`  *(digest-pinned, flags wired)*

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: model-gateway
  namespace: PLACEHOLDER_NS
  labels: { app: model-gateway }
spec:
  replicas: 2
  selector: { matchLabels: { app: model-gateway } }
  template:
    metadata:
      labels: { app: model-gateway }
      annotations:
        rtt.opt/digests: "7b1c...c0a9, 9e3f...12ab"
    spec:
      containers:
        - name: gw
          image: ghcr.io/yourorg/model-gateway@sha256:abcdef...  # digest only
          env:
            - { name: MCP_PLAN_BIN, value: "/opt/mcp/node@sha256:7b1c.../bin:/opt/mcp/claude-flow@sha256:9e3f.../bin" }
            - { name: MCP_VERIFY_DIGEST, value: "1" }
            - { name: OPENFEATURE_FLAG_FILE, value: "/flags/flags.json" }
            - { name: OPA_URL, value: "http://opa.PLACEHOLDER_NS.svc:8181" }
            - { name: NATS_URL, value: "nats://nats.PLACEHOLDER_NS.svc:4222" }
          volumeMounts: [ { name: flags, mountPath: /flags, readOnly: true } ]
          ports: [ { containerPort: 8080 } ]
      volumes:
        - name: flags
          configMap: { name: openfeature-flags }
```

## `kustomize/base/kustomization.yaml`

```yaml
resources:
  - namespaces.yaml
  - flags-configmap.yaml
  - gatekeeper-constraints.yaml
  - gateway-deploy.yaml
commonAnnotations:
  managed-by: agentic-matrix
```

## Overlays per quadrant (example: DX)

### `kustomize/overlays/dev-experimental/kustomization.yaml`

```yaml
namespace: dx
resources:
  - ../../base
replacements:
  - source:
      kind: Namespace
      name: dx
      fieldPath: metadata.name
    targets:
      - select: { kind: ConfigMap, name: openfeature-flags }
        fieldPaths: [ metadata.namespace ]
      - select: { kind: Deployment, name: model-gateway }
        fieldPaths: [ metadata.namespace, spec.template.spec.containers.0.env.3.value, spec.template.spec.containers.0.env.4.value ]
        options: { create: true }
      - select: { kind: K8sForbidCurrentOpt, name: forbid-current-opt }
        fieldPaths: [ metadata.namespace, spec.match.namespaces.0 ]
      - select: { kind: K8sRequireDigests, name: require-opt-digests }
        fieldPaths: [ metadata.namespace, spec.match.namespaces.0 ]
```

> Duplicate the overlay folder for `dev-governed` (`dg`), `prod-experimental` (`px`), and `prod-governed` (`pg`) by changing `namespace:` to `dg|px|pg`.

## Matrix compositor

### `kustomize/matrix/kustomization.yaml`

```yaml
resources:
  - ../overlays/dev-experimental
  - ../overlays/dev-governed
  - ../overlays/prod-experimental
  - ../overlays/prod-governed
```

---

**How to use.**

```bash
# Render all four quadrants
kubectl kustomize kustomize/matrix | kubectl apply -f -

# Or apply one quadrant at a time
kubectl kustomize kustomize/overlays/dev-experimental | kubectl apply -f -
```

**Next optional stamps (same pattern, per-namespace).** SPIRE server/agent, OPA Deployment with bundle URL, NATS+JetStream with SVID TLS, OTel Collector, DLQ watcher, Deployer adapter.
---
Here are per-namespace “stamps” you can drop into your kustomize repo. Each stamp is self-contained and label-agnostic. Replace `PLACEHOLDER_NS` (or use kustomize `replacements`) per quadrant: `dx`, `dg`, `px`, `pg`.

# 1) SPIRE (server + agent) — namespace-scoped demo

> For production, deploy a cluster SPIRE server and per-ns federation. This stamp gives each quadrant an isolated SPIRE pair to keep independence during drills.

```yaml
# stamps/spire/spire-server.yaml
apiVersion: v1
kind: ServiceAccount
metadata: { name: spire-server, namespace: PLACEHOLDER_NS }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: spire-server, namespace: PLACEHOLDER_NS, labels:{ app: spire-server } }
spec:
  replicas: 1
  selector: { matchLabels:{ app: spire-server } }
  template:
    metadata: { labels:{ app: spire-server } }
    spec:
      serviceAccountName: spire-server
      containers:
      - name: server
        image: ghcr.io/spiffe/spire-server:1.9.5
        args: ["-config","/spire/conf/server.conf"]
        ports: [{containerPort: 8081,name: api}]
        volumeMounts:
        - { name: conf, mountPath: /spire/conf }
      volumes:
      - name: conf
        configMap: { name: spire-server-conf }
---
apiVersion: v1
kind: ConfigMap
metadata: { name: spire-server-conf, namespace: PLACEHOLDER_NS }
data:
  server.conf: |
    server {
      trust_domain = "PLACEHOLDER_NS.local"
      bind_address = "0.0.0.0"
      bind_port = "8081"
      data_dir = "/spire/data"
    }
---
apiVersion: v1
kind: Service
metadata: { name: spire-server, namespace: PLACEHOLDER_NS }
spec:
  selector: { app: spire-server }
  ports: [{ port: 8081, targetPort: 8081, name: api }]
```

```yaml
# stamps/spire/spire-agent.yaml
apiVersion: v1
kind: ServiceAccount
metadata: { name: spire-agent, namespace: PLACEHOLDER_NS }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: spire-agent, namespace: PLACEHOLDER_NS, labels:{ app: spire-agent } }
spec:
  replicas: 1
  selector: { matchLabels:{ app: spire-agent } }
  template:
    metadata: { labels:{ app: spire-agent } }
    spec:
      serviceAccountName: spire-agent
      containers:
      - name: agent
        image: ghcr.io/spiffe/spire-agent:1.9.5
        args: ["-config","/spire/conf/agent.conf"]
        volumeMounts:
        - { name: conf, mountPath: /spire/conf }
        - { name: svid, mountPath: /var/run/spire }  # where workloads read SVIDs
      volumes:
      - name: conf
        configMap: { name: spire-agent-conf }
      - name: svid
        emptyDir: { medium: Memory }
---
apiVersion: v1
kind: ConfigMap
metadata: { name: spire-agent-conf, namespace: PLACEHOLDER_NS }
data:
  agent.conf: |
    agent {
      trust_domain = "PLACEHOLDER_NS.local"
      server_address = "spire-server.PLACEHOLDER_NS.svc"
      server_port = "8081"
      data_dir = "/spire/data"
      insecure_bootstrap = true
    }
```

# 2) OPA — bundle URL per namespace

```yaml
# stamps/opa/opa.yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: opa, namespace: PLACEHOLDER_NS, labels:{ app: opa } }
spec:
  replicas: 1
  selector: { matchLabels:{ app: opa } }
  template:
    metadata: { labels:{ app: opa } }
    spec:
      containers:
      - name: opa
        image: openpolicyagent/opa:0.64.0
        args: ["run","--server","--addr=0.0.0.0:8181","--log-level=info",
               "--set=bundle.service.url=$(BUNDLE_URL)"]
        env:
        - name: BUNDLE_URL
          value: "https://mcp-core.example/bundles/v2/PLACEHOLDER_NS"
        ports: [{ containerPort: 8181 }]
---
apiVersion: v1
kind: Service
metadata: { name: opa, namespace: PLACEHOLDER_NS }
spec:
  selector: { app: opa }
  ports: [{ port: 8181, targetPort: 8181 }]
```

# 3) NATS + JetStream — SVID TLS

```yaml
# stamps/nats/nats.yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: nats-conf, namespace: PLACEHOLDER_NS }
data:
  nats.conf: |
    jetstream: { max_mem: 1Gb, max_file: 10Gb }
    port: 4222
    tls {
      cert_file: "/var/run/spire/svid.pem"
      key_file: "/var/run/spire/key.pem"
      ca_file: "/var/run/spire/bundle.pem"
      verify: true
    }
    server_name: "nats-PLACEHOLDER_NS"
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: nats, namespace: PLACEHOLDER_NS, labels:{ app: nats } }
spec:
  replicas: 1
  selector: { matchLabels:{ app: nats } }
  template:
    metadata: { labels:{ app: nats } }
    spec:
      containers:
      - name: nats
        image: nats:2.10
        args: ["-c","/etc/nats/nats.conf","-js"]
        volumeMounts:
        - { name: conf, mountPath: /etc/nats }
        - { name: svid, mountPath: /var/run/spire, readOnly: true }
        ports: [{ containerPort: 4222, name: client }]
      volumes:
      - name: conf
        configMap: { name: nats-conf }
      - name: svid
        emptyDir: { medium: Memory }   # mount SVIDs here if using a CSI driver in prod
---
apiVersion: v1
kind: Service
metadata: { name: nats, namespace: PLACEHOLDER_NS }
spec:
  selector: { app: nats }
  ports: [{ port: 4222, targetPort: 4222, name: client }]
```

# 4) OTel Collector — per namespace

```yaml
# stamps/otel/otel.yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: otel-config, namespace: PLACEHOLDER_NS }
data:
  config.yaml: |
    receivers: { otlp: { protocols: { grpc: {}, http: {} } } }
    processors: { batch: {}, memory_limiter: { check_interval: 5s, limit_mib: 256, spike_limit_mib: 64 } }
    exporters: { otlp: { endpoint: "otel-backend.pg.svc:4317", tls: { insecure: true } } }
    service:
      pipelines:
        traces: { receivers: [otlp], processors: [memory_limiter, batch], exporters: [otlp] }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: otel-collector, namespace: PLACEHOLDER_NS, labels:{ app: otel-collector } }
spec:
  replicas: 1
  selector: { matchLabels:{ app: otel-collector } }
  template:
    metadata: { labels:{ app: otel-collector } }
    spec:
      containers:
      - name: otel
        image: otel/opentelemetry-collector:0.103.0
        args: ["--config=/etc/otel/config.yaml"]
        volumeMounts: [ { name: cfg, mountPath: /etc/otel } ]
      volumes:
      - name: cfg
        configMap: { name: otel-config }
```

# 5) DLQ watcher — Slack/PagerDuty alerts

```yaml
# stamps/dlq-watcher/dlq-watcher.yaml
apiVersion: v1
kind: Secret
metadata: { name: dlq-alerts, namespace: PLACEHOLDER_NS }
type: Opaque
stringData:
  slack_webhook: "https://hooks.slack.com/services/XXX/YYY/ZZZ"
  pd_routing_key: "YOUR_PD_KEY"
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: dlq-watcher, namespace: PLACEHOLDER_NS, labels:{ app: dlq-watcher } }
spec:
  replicas: 1
  selector: { matchLabels:{ app: dlq-watcher } }
  template:
    metadata: { labels:{ app: dlq-watcher } }
    spec:
      containers:
      - name: watcher
        image: ghcr.io/yourorg/dlq-watcher@sha256:abcdef...   # or :latest for dev
        env:
        - { name: NATS_URL, value: "nats://nats.PLACEHOLDER_NS.svc:4222" }
        - name: SLACK_WEBHOOK
          valueFrom: { secretKeyRef: { name: dlq-alerts, key: slack_webhook } }
        - name: PD_ROUTING_KEY
          valueFrom: { secretKeyRef: { name: dlq-alerts, key: pd_routing_key } }
```

# 6) Deployer adapter — ArgoCD | Rollouts | ConfigMap

```yaml
# stamps/deployer/deployer.yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: deployer, namespace: PLACEHOLDER_NS, labels:{ app: deployer } }
spec:
  replicas: 1
  selector: { matchLabels:{ app: deployer } }
  template:
    metadata: { labels:{ app: deployer } }
    spec:
      containers:
      - name: deployer
        image: ghcr.io/yourorg/deployer@sha256:abcdef...
        env:
        - { name: NATS_URL, value: "nats://nats.PLACEHOLDER_NS.svc:4222" }
        - { name: APPLY_MODE, value: "configmap" }   # configmap|argocd|rollouts
        - { name: FLAGS_NS, value: "PLACEHOLDER_NS" }
        - { name: FLAGS_CM, value: "openfeature-flags" }
        - { name: ARGOCD_URL, value: "https://argocd.example.com" }
        - name: ARGOCD_TOKEN
          valueFrom: { secretKeyRef: { name: argocd-token, key: token } }
        - { name: ROLLOUTS_NS, value: "PLACEHOLDER_NS" }
        - { name: ROLLOUTS_NAME, value: "model-gateway" }
---
apiVersion: v1
kind: Secret
metadata: { name: argocd-token, namespace: PLACEHOLDER_NS }
type: Opaque
stringData:
  token: "REDACTED"
```

# Kustomize wiring (per quadrant)

```yaml
# stamps/<component>/kustomization.yaml (pattern)
resources:
  - <component>.yaml
```

```yaml
# overlays/<quad>/kustomization.yaml — add stamps to a quadrant
namespace: dx   # or dg/px/pg
resources:
  - ../../kustomize/base
  - ../../stamps/spire
  - ../../stamps/opa
  - ../../stamps/nats
  - ../../stamps/otel
  - ../../stamps/dlq-watcher
  - ../../stamps/deployer
replacements:
  - source: { kind: Namespace, name: dx, fieldPath: metadata.name }
    targets:
      - select: { kind: ConfigMap, name: nats-conf }
        fieldPaths: [ metadata.namespace ]
      - select: { kind: Deployment, name: nats }
        fieldPaths: [ metadata.namespace ]
      - select: { kind: Service, name: nats }
        fieldPaths: [ metadata.namespace ]
      - select: { kind: Deployment, name: opa }
        fieldPaths: [ metadata.namespace, spec.template.spec.containers.0.env.0.value ]
      - select: { kind: Service, name: opa }
        fieldPaths: [ metadata.namespace ]
      - select: { kind: ConfigMap, name: otel-config }
        fieldPaths: [ metadata.namespace ]
      - select: { kind: Deployment, name: otel-collector }
        fieldPaths: [ metadata.namespace ]
      - select: { kind: Deployment, name: dlq-watcher }
        fieldPaths: [ metadata.namespace, spec.template.spec.containers.0.env.0.value ]
      - select: { kind: Deployment, name: deployer }
        fieldPaths: [ metadata.namespace, spec.template.spec.containers.0.env.0.value,
                      spec.template.spec.containers.0.env.2.value, spec.template.spec.containers.0.env.3.value,
                      spec.template.spec.containers.0.env.5.value, spec.template.spec.containers.0.env.6.value ]
```

# Notes

* Replace the SPIRE SVID mount with the **SPIFFE CSI driver** in production. Point NATS `tls.cert_file|key_file|ca_file` to that mount.
* If you already installed Gatekeeper **ConstraintTemplates**, keep quadrant-scoped **Constraints** only.
* OPA `BUNDLE_URL` can be quadrant-specific (mirror) or pointed at Core with per-ns auth.
* The `deployer` consumes `mcp.rollouts` and applies via your chosen mode.

If you want, I can produce a zipped repo skeleton with these folders rendered for all four quadrants.
---

