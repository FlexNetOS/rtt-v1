---
title: "3-Plane vs Matrix Architecture for RTT and MCP"
date: 2024-06-10
draft: true
tags: ["architecture", "rtt", "mcp", "planes", "matrix"]
---
# Summary
Short answer: keep RTT as the execution fabric for planes 1 and 2, make MCP the policy, identity, and promotion brain in plane 0. Add a fourth, lightweight observation-and-knowledge plane for truth and routing intelligence. Enforce content-addressed, signed bundles end to end. Promotions are shadow→canary→blue/green driven by SLO, budget, and invariants. No global installs. Everything by digest.

# Placement map

| Plane               | Purpose                                | Runs here                                                                                                                                    | RTT role                                                                     | MCP role                                                                               |
| ------------------- | -------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| **pln-0-orch**      | Orchestration and governance           | OPA/Gatekeeper, SPIRE, NATS+JetStream, Deployer adapters (ArgoCD/Rollouts/ConfigMap), Vault/ExtSecrets, OTel, Policy bundles, Budget service | Executes tiny control utilities only                                         | **Primary**: policy checks, signing, rollout decisions, identity, audit, drift control |
| **pln-1-sndbx-dev** | Sandboxes, symbol extraction, learning | APO (SymbolProbe/WiringSynth/ProofForge/AdmissionSim), build farms, emulators, multi-lang agent frameworks                                   | **Heavy**: run tools, scrapers, test agents, WASM filters in-preview         | Secondary: capture SBOMs, attest, store to CAS/Nexus, push candidate plans             |
| **pln-2-act-pr**    | Active product                         | Gateways, agent mesh, adapters, realtime lanes, feature flags                                                                                | **Primary**: production execution with SHM/UDS/QUIC lanes, WASM transformers | Oversees SLOs, cost, flags, promotions, incident controls                              |

Add **pln-∞-obs** (optional but recommended): the observation/knowledge plane. Hosts the symbol+data lineage graph (Neo4j), analytics stores, and model routing intelligence. Feeds decisions back to plane 0.

# “Secret” patterns the top 0.001% actually use

* **Content-address everything.** `/opt/mcp/<pkg>@sha256:<digest>` only. All tools invoked via shims. No tags.
* **Typed contracts everywhere.** JSON-Schema on all tool IO. Coercion + validation in-line via WASM filters.
* **Shadow by default.** Every change runs shadow traffic with recording and cost metering before canary.
* **Budgets are resources.** Tokens for dollars, latency, residency; admission denies when exceeded.
* **Identity plane first.** SPIFFE SVIDs on all hops: NATS, ingress, service-to-service. Deny-by-default.
* **Graph-routed planning.** Route by a live symbol↔tool↔data graph, not static configs.
* **Churn bounds.** Optimizers cap daily rollout churn to limit risk and cache invalidations.

# How RTT and MCP implement the three planes

## pln-0-orch

* **MCP**:

  * OPA bundles: invariants (immutability, residency, provider safety, schema coercion).
  * Gatekeeper: require plan annotations, forbid `/opt/mcp/current`, pin images by digest.
  * SPIRE: SVID issuance; NATS and Envoy mTLS.
  * Deployer adapters: ArgoCD sync, Rollouts weight patch, or OpenFeature ConfigMap writer.
  * JetStream streams: `mcp.events`, `mcp.rollouts`, DLQs with retries and alerts.
  * OTel collector: GenAI spans with token costs and budgets.
  * **Truth verification**: compare plan hash ↔ attestation ↔ SBOM ↔ live image digests; reject drift.

## pln-1-sndbx-dev

* **RTT**: run APO to auto-scan repos, extract symbols, synthesize adapters, generate RTT manifests, and stage plans.
* **MCP**: ProofForge signs manifests; AdmissionSim runs OPA dry-run; publish signed `mcp.apo.plan`.
* **Backups**: keep CAS, Nexus, SBOMs, provenance, and graph snapshots here. Not in prod.

## pln-2-act-pr

* **RTT**: model gateway, agent mesh (NATS), adapters (DB, vector), realtime lanes (TURN/WebRTC), WASM transformers pre/post egress.
* **MCP**: OpenFeature flags drive traffic weights; rollout agent enforces OPA before promotion; budgets enforced; auto-rollback on SLO regression.

# Build goals → concrete mechanics

1. **Dynamic UI/UX**

   * Single console shows plan diffs, OPA decisions, trace links, flags, budget burn, and residency map.
   * “Wiring loom” view: unmatched ports, suggested quick-connects, one-click apply.

2. **Cross-platform adaptability**

   * All tools delivered as signed OCI or tar to `/opt/mcp/@digest`. Shims in `/usr/bin`.
   * VFS/FUSE for CAS; WinFsp on Windows. Envoy for h2c→mTLS everywhere.

3. **Client↔host switching / host absorption**

   * Gateway runs in **dual mode**: if provider creds present → client; else advertise as host over mTLS.
   * TURN+WebRTC enables remote absorb and local short-circuit when peers co-locate.

4. **Environment aware**

   * Detect residency/PII and select providers accordingly via OPA `provider_safety` rules.
   * Node-local SHM/UDS lanes preferred; QUIC fallback with TURN.

5. **Self-update, self-healing**

   * APO watches `/dropin` and registries; builds missing connectors; emits signed plans.
   * JetStream retries, DLQ watcher with Slack/PagerDuty; drift controller re-materializes `/opt` from CAS.

6. **No-human operation**

   * Plan lifecycle: discover → prove → shadow → canary → green under SLO+budget gates.
   * Only user input: goal request. Planner selects tools and lanes by graph and policies.

7. **Adaptive, self-reinventing**

   * SLLM (llama.cpp) classifies new artifacts, fills schemas, generates adapter stubs and tests.
   * Optimizer retunes routes and placement with churn caps and budget.

8. **Upgrade-only semantics**

   * Monotonic plan IDs and version lattice. Lower digests rejected by Gatekeeper.
   * Emergency rollback guarded by break-glass policy and audit.

# Filesystem and layout per plane

* **/usr**: read-only shims only.
* **/opt/mcp**: content-addressed bundles; read-only in prod.
* **/var/lib/mcp**: CAS index, graph cache, SQLite for dev.
* **/tmp**: tmpfs, noexec, scrubbed; WASM scratch.
* **$HOME/.mcp**: flags, aliases, caches; no secrets.
* **Backups**: MCP stores only—plans, policies, CAS, Nexus, graph, audit logs—with object-lock.

# End-to-end automation loop

1. **Discover**: APO probes code, drivers, firmware; emits symbols and candidate tools.
2. **Prove**: SBOM + SLSA attest + Ed25519 sign.
3. **Plan**: solver selects tools, lanes, placement; computes budgets and flags.
4. **Admit**: OPA+Gatekeeper pass, SPIRE identity attached.
5. **Execute**: RTT runs; WASM filters enforce schema/PII; OTel spans include tokens and costs.
6. **Observe**: SLO and budget signals feed optimizer.
7. **Promote**: shadow→canary→blue/green via deployer adapter.
8. **Seal**: freeze plan; update graph; snapshot MCP stores.

# What you are missing

* **Observation plane** (pln-∞): independent telemetry, graph, and replay to avoid feedback bias.
* **Provider contract tests** per model/tool with golden vectors and structured-output coercion.
* **Policy-backed cost ceilings** at admission time.
* **Drift budgets** to prevent high churn.
* **Speculative prefetch** of likely next tools and models based on the graph.
* **Cold-start catalog**: pre-warmed WASM pools and model contexts per tenant.

# Better than three planes?

* Keep the **three-plane mental model**, deploy as **one cluster** with namespaces and labels: `plane=orch|sndbx|prod`. Promotions are label flips, not network hops.
* Or adopt a **2×2 matrix**: {dev, prod} × {governed, experimental}. Plane 0 becomes the governed control column; plane ∞ is observation across both.
* The three-plane split remains simplest to reason about. Add pln-∞ for truth and routing intelligence.

# Minimal control contracts to lock it in

* **Gatekeeper**: required annotations (`rtt.plan/hash`, `…/signed`, `…/providers`, `rtt.opt/digests`), forbid `/opt/mcp/current`, pinned image digests.
* **OPA**: `plan_invariants.rego`, `schema_coercion.rego`, `provider_safety.rego`, budget checks.
* **SPIRE**: SVIDs on NATS and ingress; registration entries by label selectors.
* **OpenFeature**: `plan.canaryWeight` flag bound to gateway route picker.
* **NATS JetStream**: retries, DLQ with alerts.
* **WASM runtime**: pooled, timeouts, byte caps, fixed memory.

# Quick wiring checklist per plane

* **pln-0-orch**: OPA+Gatekeeper bundles loaded; SPIRE server+agent; NATS with mTLS; Deployer adapter chosen; OTel collector live.
* **pln-1-sndbx-dev**: APO watching `/dropin`; CAS+VFS mounted; signing keys in Vault; shadow env; DLQ watcher.
* **pln-2-act-pr**: Gateway with OpenFeature; WASM filters on request/response; agents on NATS; adapters pinned by digest; telemetry exporting.

If needed, I can collapse this into a one-page PRD addendum and a set of namespace kustomizations to label a single cluster into the three planes.

---
Recommendation: keep the planes **independent**. Each plane runs its **own RTT** and a **minimal MCP-Edge**. Plane-0 hosts **MCP-Core** for policy authoring, signing, rollout control, and audit. Use content-addressed artifacts and federated identity so any plane can assume traffic with no rebuild.

# 1) Independence and failover

* **Identity**: one SPIFFE *trust domain per plane* with federation. Plane SVIDs remain valid cross-plane for emergency takeover.
* **Event fabric**: one NATS+JetStream per plane. Bridge with **leafnodes**. If links drop, planes operate solo; when links return, **mirrors** reconcile.
* **Artifacts**: global CAS in object storage with multi-region replication. Each plane has a **read-only CAS cache**. Plans reference digests, so takeover = mount and run.
* **Truth**: append-only transparency log (Rekor-style). Every plan, SBOM, attestation, and rollout vote recorded. Any plane can verify without talking to another.
* **Traffic swap**: anycast/GSLB in front. Plane health + SLO guard flips DNS or LB weights. Blue/green spans **across planes** when needed.

# 2) Do they each need RTT and MCP?

| Plane               | RTT (must)                                           | MCP-Edge (recommended)                                | MCP-Core (central)                                      |
| ------------------- | ---------------------------------------------------- | ----------------------------------------------------- | ------------------------------------------------------- |
| **pln-0-orch**      | tiny utilities only                                  | OPA, Gatekeeper, SPIRE, NATS, Deployer adapters, OTel | **Yes**: policy authoring, signing HSM, audits, budgets |
| **pln-1-sndbx-dev** | **Full**: APO, emulators, builders, test gateways    | OPA dry-run, local SPIRE, local JetStream             | Optional (read-only snapshot of Core)                   |
| **pln-2-act-pr**    | **Full**: production gateway, agents, adapters, WASM | OPA enforce, SPIRE, JetStream, flags                  | Optional (read-only snapshot for isolation mode)        |

Notes

* **RTT per plane is mandatory**. It is the execution fabric.
* **MCP-Edge per plane** avoids a plane-0 SPOF and enables isolated operation.
* **MCP-Core** ideally only in plane-0 with **threshold signing (t-of-n HSM)**; distribute read-only bundles to planes 1 and 2.

# 3) 3-planes vs 2×2 matrix

**Three planes (tree)**

* Pros: clear roles, simple mental model, easy blast-radius control.
* Cons: promotions cross a single axis only; experimentation sometimes bleeds into prod via exceptions.

**2×2 matrix = {dev,prod} × {governed,experimental}**

* Pros: orthogonal control. You can run **prod+experimental** shadow lanes without violating **governed** policy; policy deltas live on the governance axis. Better fit for feature flags and A/Bs.
* Cons: more states to manage, higher policy drift risk, harder incident drills. Needs solid labeling and automation.

**High-value “secret” for matrix systems**

* Treat environments as **labels**, not clusters. Every plan evaluates **row/column constraints**:
  `allow ⇔ invariants(row) ∧ invariants(column) ∧ budgets`.
* Maintain a **state lattice** with *upgrade-only edges*. Rollouts are monotone moves in this lattice.
* Embed plans and environments into vectors (symbol/graph embeddings). Use **nearest-feasible** selection to route traffic and prewarm caches. This is the transformer-era advantage: **learned placement** over a constraint lattice.

# 4) Plane roles applied to RTT/MCP

**pln-0-orch (MCP-Core + MCC)**

* Policy bundles, signing, budget scheduler, deployer adapters (ArgoCD/Rollouts/ConfigMap), transparency log, cross-plane audits.
* RTT runs tiny control tasks only.

**pln-1-sndbx-dev (builder/learner)**

* RTT: APO scans, symbol extraction, stub synthesis, shadow runs.
* MCP-Edge: OPA dry-run, local SPIRE, local JetStream and OTel for fast loops.
* Holds **backups**: CAS, SBOMs, graph, provenance.

**pln-2-act-pr (product)**

* RTT: gateways, agents, adapters, real-time lanes, WASM filters; OpenFeature for weights.
* MCP-Edge: enforce policy, budgets, and identity on every hop; local failover if plane-0 is absent.

# 5) Zero-touch takeover when plane-2 fails

* Anycast VIP points to planes 2→1→0 by health.
* Plans and artifacts already present by digest and policy snapshot.
* SPIRE federation admits plane-1 SVIDs to prod LB.
* Deployer adapter promotes **shadow on plane-1** to **green** under the same plan hash.
* Observability proves SLO parity; transparency log records quorum vote.

# 6) What you may still miss

* **Quorum rollouts**: require ≥2 planes to sign promotion.
* **Budget as a first-class resource** at admission (tokens for $ and latency).
* **Drift budgets**: limit daily plan churn.
* **Speculative prefetch**: warm likely next routes, embeddings, and WASM pools.
* **Emergency signer** in each plane with *time-boxed* validity, auto-revoked when Core returns.

# 7) Implementation deltas to lock independence

* One **SPIRE server per plane**, federated trust roots; workload selectors are the same across planes.
* One **NATS+JetStream per plane**; **leafnode bridges** when available; **DLQ** in every plane.
* **CAS global** with local caches; read-only in prod.
* **OPA+Gatekeeper** installed per plane with the same bundle revision; **opa-bundle-revision** label pinned on every rollout.
* **OpenFeature** flags resolved locally; config mirrored via GitOps branch per plane.

# 8) UI/UX

* Plane picker with uniform views: plans, flags, budgets, audits, traces.
* “Ready to assume” indicator shows if a plane has the plan hash, policy bundle rev, and warm pools.
* Cross-plane diff and **vote pane** for quorum promotions.

If you confirm the independence stance and whether you prefer **three planes** or **2×2 matrix**, I’ll collapse everything into a one-page PRD addendum and produce namespace kustomizations to label a single cluster with `plane=orch|sndbx|prod` (or the matrix labels) and wire SPIRE, NATS, OPA, Gatekeeper, and OpenFeature accordingly.
---
