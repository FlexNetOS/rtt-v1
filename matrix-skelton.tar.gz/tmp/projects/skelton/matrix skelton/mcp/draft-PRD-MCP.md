You need four pillars: zero-copy lanes, typed contracts with attestations, plan-gated orchestration, and unified observability. Build the MCP Server to those.

# MCP Server — PRD draft (Oct 2025)

## 1) Goal

A production-grade MCP Server that exposes tools/resources/prompts with strict contracts, low-latency transports, plan-gated execution, and first-class integration with the RTT relay (CAS, signed plans, admission, placement). Must run locally and in K8s. Must auto-discover, auto-ingest, and auto-attest.

## 2) Non-goals

* Building an LLM.
* Replacing model gateways (we integrate).
* Long-term state store (we integrate with DBs).

## 3) Users and top jobs

* **Agent host** (Claude Desktop, IDEs, custom hosts) needs an MCP endpoint that is secure, fast, and typed. ([Model Context Protocol][1])
* **Platform team** needs policy, audit, and SLOs.
* **Tool owners** need schema-first development and attestations.

## 4) Landscape signals

* Official MCP spec, SDKs, and reference servers (TS, Python; growing language set). ([GitHub][2])
* IDEs and Microsoft ship MCP client support. ([Microsoft Learn][3])
* Realtime/WebRTC paths are now standard for low-latency agent I/O. ([OpenAI Platform][4])
* OTel GenAI semantic conventions and OpenInference are the telemetry baseline. ([OpenTelemetry][5])
* Model gateways (LiteLLM, OpenRouter) provide routing, budgets, and fallbacks. ([GitHub][6])

## 5) Success metrics

* P50/P95 tool round-trip: ≤20 ms / ≤80 ms local, ≤120 ms / ≤300 ms remote.
* ≥99.9% successful tool invokes under SLO budgets.
* 100% plans applied only if verified signature + invariants pass.
* <1% weekly churn in placement/lane changes at steady state.
* 100% spans emitted with OTel GenAI semconv. ([OpenTelemetry][5])

---

## 6) Functional requirements

### F1. MCP protocol compliance

* Tools, Resources, Prompts, Schemas, Errors, and Transports (stdio, SSE/HTTP; add WebRTC streamable HTTP where host supports it). ([GitHub][2])

### F2. Dual-lane transport

* **Fast path (local):** Unix-domain + SHM ring via `memfd_create` and FD passing; fall back to UDS framed JSON.
* **Network path:** WebRTC/QUIC with ICE (STUN+TURN). Configurable TURN pools. ([OpenAI Platform][4])

### F3. Contract authority

* JSON-Schema as source of truth for tool I/O; optional Smithy/IDL mapping. Strict structured output at the model boundary enforced server-side and in RTT. ([GitHub][7])

### F4. Security and attestations

* Sign server releases and manifests; generate in-toto/SLSA attestations; verify with Sigstore/cosign at deploy and at plan-apply. ([SLSA][8])

### F5. Policy + admission

* OPA/Gatekeeper policies on which tools/resources are callable, per-tenant budgets, data-residency. Deny on policy miss. ([openpolicyagent.org][9])

### F6. Observability

* Emit OTel GenAI spans for every invoke; Collector deployment profiles for K8s (DaemonSet for node spans, Deployment for gateway). ([OpenTelemetry][10])

### F7. Model gateway integration

* Native clients for LiteLLM/OpenRouter with per-tenant rate and spend budgets; fallback trees. ([GitHub][6])

### F8. RTT integration

* Emit RTT-style manifests to `.rtt/manifests/`; publish into CAS; participate in signed plans. Builder enforces invariants, ILP admission, placement, and lanes before execution.

### F9. Auto-ingest and registry

* Scan `mcp/*.json` tool descriptors, generate server configs, and register to index. Pull from community catalogs to seed tools. ([GitHub][11])

### F10. Dev experience

* Codegen stubs for TS, Python, Go, Rust, C#, Java; test harness with schema fuzzing and golden traces.

---

## 7) Non-functional requirements

* **Latency:** SHM lane target ≤5 ms P50 local; WebRTC lane ≤80 ms P50 cross-region with TURN. ([WebRTC.ventures][12])
* **Reliability:** 99.95% monthly availability.
* **Security:** SLSA-2+ for builds; cosign verify on boot; OPA policies mandatory. ([SLSA][13])
* **Compliance:** audit trails via OTel and signed execution transcripts.
* **Scalability:** 10k concurrent tool invokes per cluster with gateway Collectors. ([ControlTheory][14])

---

## 8) Architecture

### Components

* **Transport adapters:** stdio, HTTP/SSE, WebRTC/QUIC. ([OpenAI Platform][4])
* **Schema engine:** JSON-Schema validation; coercion; structured output enforcement.
* **Policy layer:** OPA authorizer + per-tenant quotas. ([Kubernetes][15])
* **Execution runtime:** thread-pool + SHM ring for local; SRTP data channels for network.
* **Telemetry:** OTel SDK + Collector (DaemonSet + gateway). ([OpenTelemetry][10])
* **RTT bridge:** emits manifests; subscribes to signed plans; enforces invariant gate and admission decisions.
* **Attestation agent:** signs manifests and plans; verifies at boot and plan apply. ([Sigstore][16])

### Data contracts

* **Tool schema:** JSON-Schema; versions and compatibility declared.
* **Manifest schema:** symbol `saddr`, `version_set`, `qos`, `tags.supports_shm`.
* **Plan contract:** signed plan with placement + lanes.

---

## 9) DevOps design

### Supply chain

* Build with SLSA provenance; publish OCI images and in-toto attestations; cosign verify in CI and at cluster admission. ([SLSA][8])

### Kubernetes

* **OPA Gatekeeper** enforces MCP Server admission (required labels, cosign verification, network policies). ([openpolicyagent.org][9])
* **OTel Collector**: DaemonSet for node spans; Deployment as gateway; follow security best practices. ([OpenTelemetry][10])
* **WebRTC infra**: STUN+TURN pools (coturn/managed); HA and autoscale guidance. ([WebRTC.ventures][12])

### Hardening note

* If you add `io_uring` optimizations, ensure EDR visibility; recent research shows common blind spots. ([TechRadar][17])

---

## 10) Backlog and phases

### Phase A — Foundations (MVP)

* MCP spec compliance (TS + Python), stdio + HTTP transports.
* JSON-Schema enforcement; OTel GenAI spans; file/HTTP tools; RTT manifest emitter. ([GitHub][2])

### Phase B — Low-latency + Policy

* WebRTC/QUIC adapter with STUN/TURN; SHM lane for local.
* OPA policies; cosign verify at startup; CAS + signed plan-only execution. ([OpenAI Platform][4])

### Phase C — Admission + Placement

* ILP admission with capacity and QoS budgets; churn-aware placement; lane selection.
* Model-gateway drivers (LiteLLM/OpenRouter). ([GitHub][6])

### Phase D — Automation

* Auto-ingest community servers; codegen stubs; regression suites; chaos testing; autoscaling controllers.

---

## 11) Open-source to adopt

* **MCP core:** modelcontextprotocol/spec, TypeScript SDK, Python SDK, reference servers. ([GitHub][2])
* **Community catalogs:** awesome-mcp-servers, directories. ([GitHub][18])
* **GitHub MCP Server:** production example and config patterns. ([GitHub][19])
* **Realtime:** OpenAI Realtime API (WebRTC, SIP). ([OpenAI Platform][4])
* **Observability:** OTel GenAI semconv; OpenInference. ([OpenTelemetry][5])
* **Gateways:** LiteLLM, OpenRouter. ([GitHub][6])
* **Policy:** OPA/Gatekeeper. ([openpolicyagent.org][9])
* **TURN/STUN:** coturn deployment guides and best practices. ([WebRTC.ventures][12])
* **Supply chain:** SLSA, in-toto, cosign. ([SLSA][8])

---

## 12) The “secret formula” applied

* **Zero-copy first:** SHM rings with FD-passing for local; WebRTC/QUIC for remote. Keep FUSE/WinFsp only for namespace, not hot paths. ([OpenAI Platform][4])
* **Typed + attested:** schemas are authoritative; every manifest and plan carries in-toto/SLSA attestations. ([in-toto][20])
* **Plan→Admit gates:** invariant check, policy check, budget/placement solve, then sign and apply.
* **Unified traces + budgets:** OTel GenAI spans and per-tenant budget enforcement. ([OpenTelemetry][5])

---

## 13) Detailed requirements

### Contracts

* JSON-Schema v7+ for all tool I/O; strict mode default.
* Versioning policy with `version_set` ranges in manifests.

### Security

* Mutual auth options: OIDC-backed token for remote MCP; OS-user binding for stdio.
* Policy: Allow/deny by tool, verb, tenant, data class; signed config.

### Performance budgets

* Lane cost model baked into solver. SHM default if co-located and `tags.supports_shm=true`.
* Backpressure using token buckets + WFQ queues at the MCP invoke gateway.

### Compatibility

* Hosts: Claude Desktop, VS/VSCode/Cursor via MCP client; remote over HTTP/WebRTC. ([Model Context Protocol][1])

### Testing

* Contract tests auto-generated from schemas.
* Fuzz invalid inputs.
* Golden trace replays ensure SLOs.
* Chaos: TURN exhaustion, host disconnects, quota spikes.

### Deployment

* Helm charts with cosign-verify init container; Gatekeeper constraints; OTel Operator optional. ([OpenTelemetry][10])

---

## 14) What you’re still missing

1. **TURN fleet and QoS policy** for realtime lanes; many teams forget HA TURN and monitoring. ([WebRTC.ventures][12])
2. **Cosign verification at cluster admission** tied to Gatekeeper; most only verify in CI. ([openpolicyagent.org][9])
3. **OTel GenAI spans everywhere,** not just the LLM call; include tool invocations and RTT plan IDs. ([OpenTelemetry][5])
4. **Community auto-ingest,** so new servers appear without manual wiring. ([GitHub][11])
5. **io_uring visibility** if you optimize I/O; add detections to avoid blind spots. ([TechRadar][17])

---

## 15) Full automation plan (MCP × RTT)

**Discover → Ingest → Plan → Prove → Admit → Execute → Observe → Autotune**

1. **Discover** MCP configs in repo and catalogs; fetch server descriptors. ([GitHub][11])
2. **Ingest** into RTT CAS; emit manifests with `qos`, `version_set`, `supports_shm`.
3. **Plan** routes with ILP solver: maximize admissions, minimize latency and churn; produce placement + lanes.
4. **Prove** with in-toto/SLSA attestations; cosign-verify manifests and plan. ([in-toto][20])
5. **Admit** via OPA policy and per-tenant budgets; reject on violation. ([openpolicyagent.org][9])
6. **Execute**: local SHM or WebRTC path; fallback to HTTP/SSE. ([OpenAI Platform][4])
7. **Observe** with OTel; export spans and metrics; attach plan IDs; store transcripts. ([OpenTelemetry][5])
8. **Autotune**: update placement, lane prefs, and TURN pools from telemetry; re-plan only if benefit > churn threshold.

**Agents/tools/skills to add**

* **Plan builder agents:** invariant gate, ILP optimizer, churn guard.
* **Telemetry agent:** detects hot spots, proposes SHM/WebRTC escalation.
* **Policy agent:** compiles high-level rules to Rego; tests constraints.
* **Gateway agent:** picks model via latency/cost SLOs; uses LiteLLM/OpenRouter. ([GitHub][6])
* **Attestation agent:** emits/validates in-toto predicates for every deploy and plan. ([Sigstore][16])

---

## 16) Acceptance criteria

* Passes MCP conformance tests; connects to Claude Desktop and GitHub MCP Server end-to-end. ([Model Context Protocol][1])
* SHM + WebRTC lanes operational with working TURN failover. ([WebRTC.ventures][12])
* OPA Gatekeeper blocks unsigned or policy-violating deploys. ([openpolicyagent.org][9])
* OTel traces present for tools/resources/prompts with GenAI semconv. ([OpenTelemetry][5])
* Signed plan-only execution with verify step; ILP admission and placement embedded.

If you want, I can add Helm charts with Gatekeeper constraints, OTel pipelines, TURN pool templates, and a minimal MCP Server skeleton wired to RTT manifests.

[1]: https://modelcontextprotocol.io/docs/develop/build-server?utm_source=chatgpt.com "Build an MCP server"
[2]: https://github.com/modelcontextprotocol/modelcontextprotocol?utm_source=chatgpt.com "Specification and documentation for the Model Context ..."
[3]: https://learn.microsoft.com/en-us/visualstudio/ide/mcp-servers?view=vs-2022&utm_source=chatgpt.com "Use MCP Servers - Visual Studio (Windows)"
[4]: https://platform.openai.com/docs/guides/realtime-webrtc?utm_source=chatgpt.com "OpenAI Realtime API using WebRTC"
[5]: https://opentelemetry.io/docs/specs/semconv/gen-ai/?utm_source=chatgpt.com "Semantic conventions for generative AI systems"
[6]: https://github.com/BerriAI/litellm?utm_source=chatgpt.com "BerriAI/litellm: Python SDK, Proxy Server (LLM Gateway) to call ..."
[7]: https://github.com/modelcontextprotocol/typescript-sdk?utm_source=chatgpt.com "modelcontextprotocol/typescript-sdk"
[8]: https://slsa.dev/?utm_source=chatgpt.com "SLSA • Supply-chain Levels for Software Artifacts"
[9]: https://openpolicyagent.org/docs/kubernetes?utm_source=chatgpt.com "Overview & Architecture"
[10]: https://opentelemetry.io/docs/demo/kubernetes-deployment/?utm_source=chatgpt.com "Kubernetes deployment"
[11]: https://github.com/modelcontextprotocol/servers?utm_source=chatgpt.com "modelcontextprotocol/servers: Model Context Protocol ..."
[12]: https://webrtc.ventures/2025/01/how-to-set-up-self-hosted-stun-turn-servers-for-webrtc-applications/?utm_source=chatgpt.com "How to Set Up Self-Hosted STUN/TURN Servers for ..."
[13]: https://slsa.dev/spec/latest/levels?utm_source=chatgpt.com "Security levels"
[14]: https://www.controltheory.com/resources/opentelemetry-collector-deployment-patterns-a-guide/?utm_source=chatgpt.com "OpenTelemetry Collector Deployment Patterns: A Guide"
[15]: https://kubernetes.io/blog/2019/08/06/opa-gatekeeper-policy-and-governance-for-kubernetes/?utm_source=chatgpt.com "OPA Gatekeeper: Policy and Governance for Kubernetes"
[16]: https://docs.sigstore.dev/cosign/verifying/attestation/?utm_source=chatgpt.com "In-Toto Attestations"
[17]: https://www.techradar.com/pro/security/a-worrying-stealthy-linux-security-bug-could-put-your-systems-at-risk-heres-what-we-know?utm_source=chatgpt.com "A worrying stealthy Linux security bug could put your systems at risk - here's what we know"
[18]: https://github.com/punkpeye/awesome-mcp-servers?utm_source=chatgpt.com "punkpeye/awesome-mcp-servers"
[19]: https://github.com/github/github-mcp-server?utm_source=chatgpt.com "GitHub's official MCP Server"
[20]: https://in-toto.io/docs/specs/?utm_source=chatgpt.com "Specifications"
