---
Download and drop in.

* [mcp_stack_helm_skeleton.zip](sandbox:/mnt/data/mcp_stack_helm_skeleton.zip)

## What’s included

* Minimal MCP Server (TypeScript) with strict schemas and RTT manifest exporter.
* Helm chart `mcp-stack` that deploys:

  * MCP Server Deployment + Service.
  * OTel Collector (OTLP gRPC receiver, logging + optional OTLP exporter).
  * coturn TURN pool (UDP 3478, TCP 5349) with ConfigMap + Secret.
  * Gatekeeper ConstraintTemplate + Constraint requiring `cosign.sigstore.dev/verified=true` Pod annotation.
  * Job to export RTT manifests into `/var/run/rtt/manifests`.

## Quick start

```bash
# 1) Build and push the image
cd mcp-server
pnpm i || npm i
npm run build
docker build -t ghcr.io/yourorg/mcp-server:latest .
docker push ghcr.io/yourorg/mcp-server:latest

# 2) Install the stack
helm upgrade --install mcp charts/mcp-stack -n mcp --create-namespace \
  --set image.repository=ghcr.io/yourorg/mcp-server \
  --set image.tag=latest \
  --set otelCollector.exportOtlpEndpoint="http://your-otel-gateway:4317" \
  --set coturn.realm="relay.example.com"

# 3) Access MCP
kubectl -n mcp port-forward svc/mcp-server 3000:3000
```

## Wire to RTT

* The Job `mcp-export-rtt` writes RTT manifests under `/var/run/rtt/manifests`. Point your RTT planner at that path. Plans then admit and place this MCP server’s tools using your existing ILP + churn optimizer.

## Notes

* Gatekeeper constraint enforces a cosign verification annotation. Integrate Sigstore Policy Controller or add the annotation in CI after verification.
* OTel Collector is minimal. Set `otelCollector.exportOtlpEndpoint` to forward traces and metrics to your APM.
* TURN config is basic. Replace credentials, use TLS for 5349, and scale replicas per region.
* Extend the MCP Server by adding new endpoints in `src/server.ts` and updating `src/schemas/` as needed.
---

--- END OF FILE ---

---
Missing pieces: a gateway-aware model layer, TURN-capable realtime ingress, artifact governance with Nexus, strict GenAI telemetry, and a UI that exposes plans, lanes, budgets, and traces. Map each named tool into that system and automate from discovery to re-plan.

# Where each fits

| Component                             | Role in your stack                                                                                                                                                                                                                                                | Wire point                                                                          |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| **Claude Code**                       | Coding agents and repo actions. Treat as an MCP **client/host** that calls your MCP servers. Also expose it as a remote tool runner over Web via Realtime when voice or low-latency is needed. Supports a web app and GitHub-linked repos. ([Windows Central][1]) | Realtime lane + HTTP lane through RTT plan.                                         |
| **Claude-flow**                       | Use as flow orchestration if you have it. Import flows as typed tools (schemas) or wrap the flow endpoint as an MCP server. Expose flow steps as resources for observability.                                                                                     |                                                                                     |
| **nexus (Sonatype Nexus Repository)** | Central artifact registry and SBOM source for images, plugins, schemas, and signed plans. Use its APIs to publish and fetch OCI artifacts and policies. ([Sonatype Help][2])                                                                                      | DevSecOps path. Gatekeeper checks require Cosign-verified images pulled from Nexus. |
| **caddy**                             | Edge ingress and reverse proxy with HTTP/3. Terminate TLS. Proxy MCP HTTP and signaling for Realtime. Keep media relay on coturn. ([Caddy Web Server][3])                                                                                                         | Ingress for MCP servers and WebRTC signaling.                                       |
| **llama.cpp**                         | Local inference runtime. Run as a sidecar or node service. Expose via an MCP server or route through a model gateway. Favor SHM lanes on same node. ([GitHub][4])                                                                                                 | Provider behind LiteLLM/OpenRouter or direct MCP.                                   |
| **codex**                             | Deprecated. Replace with Claude Code, Copilot, Cursor, or other code agents. Keep an abstract “code-assistant” provider so swaps are zero-touch. ([Augment Code][5])                                                                                              |                                                                                     |
| **MCP spec + clients**                | Protocol standard. Treat MCP servers as first-class endpoints in RTT. ([Model Context Protocol][6])                                                                                                                                                               |                                                                                     |
| **Realtime API**                      | Network fast lane with WebRTC or SIP. Use for remote MCP access and voice tools. ([OpenAI][7])                                                                                                                                                                    |                                                                                     |
| **OTel GenAI**                        | Mandatory spans and metrics for tools, agents, and models. Adopt the GenAI semconv. ([OpenTelemetry][8])                                                                                                                                                          |                                                                                     |

# What you’re still missing

1. **Gateway layer for models.** Add LiteLLM/OpenRouter compatibility. Route by latency, cost, and policy. Keep Claude, llama.cpp, and others behind the same interface.
2. **TURN and signaling.** You have coturn. Add Caddy for HTTPS and HTTP/3 signaling. Test ICE paths. ([Caddy Web Server][3])
3. **Artifact governance.** Push images, WASM, RTT plans, and schemas into **Nexus**. Enforce Cosign verification at admission. ([Sonatype Help][2])
4. **Strict GenAI telemetry.** Emit GenAI spans for agent, tool, and model calls. Include plan_id, route_id, and budget attributes. ([OpenTelemetry][8])
5. **Remote MCP via Realtime.** Let hosts call your MCP servers over WebRTC with TURN fallback. ([OpenAI][7])

# Full automation

**Loop:** Discover → Ingest → Plan → Prove → Admit → Execute → Observe → Autotune.

* **Discover**: Watch Git, Nexus, and MCP catalogs. Auto-pull MCP descriptors and flow defs. ([Model Context Protocol][9])
* **Ingest**: Normalize tools/resources/prompts into CAS with JSON-Schema. Generate RTT manifests.
* **Plan**: Use ILP solver for admission and placement. Prefer SHM when co-located.
* **Prove**: Create in-toto/SLSA attestations for servers and plans. Verify with Cosign. Store in Nexus.
* **Admit**: OPA decides tool access, data residency, and spend. Deny on policy miss.
* **Execute**: Local SHM or remote WebRTC. HTTP lane for control. TURN used only for media. ([OpenAI][7])
* **Observe**: OTel GenAI spans and metrics. Export via Collector. ([OpenTelemetry][8])
* **Autotune**: Re-plan when predicted gain exceeds churn threshold. Adjust lane prefs and placement from traces.

**Agents you need**

* **Catalog agent**: scans MCP repos and Nexus for new tools.
* **Schema agent**: validates and publishes JSON-Schema.
* **Plan agent**: runs invariants then ILP with QoS and capacity.
* **Admission agent**: compiles policy to OPA.
* **Gateway agent**: routes model calls across Claude, llama.cpp, others, with budgets.
* **Telemetry agent**: mines OTel traces for hotspots and SLO drift, triggers re-plan.

# UI/UX to ship

**Operator console**

* **Topology map**: symbols, lanes, nodes, and plan diffs.
* **Budget board**: per tenant cost, token use, RT caps.
* **Policy view**: OPA decisions with explain.
* **Realtime health**: TURN usage, ICE success, signaling latency.
* **Artifact trust**: Cosign status and in-toto links from Nexus.

**Developer console**

* **Contract browser**: schemas for tools/resources/prompts with sample payloads.
* **Trace explorer**: GenAI spans; drill into tool calls, TTFT, tokens. ([OpenTelemetry][10])
* **Flow runner**: trigger Claude-flow or MCP prompts; compare outputs.
* **Scaffolding**: codegen stubs for TS, Python, Go, Rust, Java.

# Integration specifics

* **Claude Code**: treat as an MCP host and optional remote runner. Use the new web app to connect repos for end-to-end PRs. Your relay provides plan-gated tool access and budgets. ([Windows Central][1])
* **Claude-flow**: expose each flow as a typed tool. Use structured outputs on every step.
* **nexus**: publish MCP server images and RTT plans as OCI artifacts. Enforce Cosign at K8s admission. ([Sonatype Help][11])
* **caddy + coturn**: Caddy for HTTPS and QUIC reverse proxy. coturn for media relay. Configure realm and credentials. ([Caddy Web Server][3])
* **llama.cpp**: run on nodes with SHM support. Expose via MCP or route through the gateway. ([GitHub][4])
* **codex**: remove direct dependency. Keep an abstract provider that maps to Claude Code, Copilot, or others. ([eesel AI][12])
* **MCP**: follow the current spec for tools, resources, prompts, transports. ([Model Context Protocol][6])
* **Realtime**: use GA Realtime API for remote MCP and phone bridges. ([OpenAI][7])
* **OTel GenAI**: implement semconv attributes for model, agent, and tool spans. Ship via Collector. ([OpenTelemetry][8])

# Final checklist

* TURN and signaling tested with ICE across NATs. ([OpenAI][7])
* Gatekeeper blocks Pods without Cosign annotation.
* Nexus hosts OCI images, WASM, schemas, and signed plans. ([Sonatype Help][2])
* OTel GenAI spans present for every invoke. ([OpenTelemetry][8])
* Gateway routes models across Claude, llama.cpp, others, under budgets.
* RTT signed plans are the only execution input.

If you want, I can add a gateway layer for models and a minimal UI bundle next.

[1]: https://www.windowscentral.com/artificial-intelligence/anthropics-claude-code-is-now-available-on-the-web-for-its-pro-and-max-users?utm_source=chatgpt.com "Claude Code comes to the web - so you can pay to manage the AI that's taking your job"
[2]: https://help.sonatype.com/en/sonatype-nexus-repository.html?utm_source=chatgpt.com "Sonatype Nexus Repository"
[3]: https://caddyserver.com/docs/quick-starts/reverse-proxy?utm_source=chatgpt.com "Reverse proxy quick-start — Caddy Documentation"
[4]: https://github.com/ggml-org/llama.cpp?utm_source=chatgpt.com "ggml-org/llama.cpp: LLM inference in C/C++"
[5]: https://www.augmentcode.com/guides/top-openai-codex-alternatives-for-enterprise-teams?utm_source=chatgpt.com "Top OpenAI Codex Alternatives for Enterprise Teams"
[6]: https://modelcontextprotocol.io/specification/2025-06-18?utm_source=chatgpt.com "Specification"
[7]: https://openai.com/index/introducing-gpt-realtime/?utm_source=chatgpt.com "Introducing gpt-realtime and Realtime API updates for ..."
[8]: https://opentelemetry.io/docs/specs/semconv/gen-ai/?utm_source=chatgpt.com "Semantic conventions for generative AI systems"
[9]: https://modelcontextprotocol.io/?utm_source=chatgpt.com "What is the Model Context Protocol (MCP)? - Model Context ..."
[10]: https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans/?utm_source=chatgpt.com "Semantic conventions for generative client AI spans"
[11]: https://help.sonatype.com/?utm_source=chatgpt.com "Sonatype Help"
[12]: https://www.eesel.ai/blog/openai-codex-alternatives?utm_source=chatgpt.com "I tested the top 5 OpenAI Codex alternatives in 2025 ..."

--- END OF FILE ---
