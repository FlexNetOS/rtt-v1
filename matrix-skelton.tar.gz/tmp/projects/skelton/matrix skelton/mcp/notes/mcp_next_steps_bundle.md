---
Delivered. Drop in and run.

* [mcp_next_steps_bundle.zip](sandbox:/mnt/data/mcp_next_steps_bundle.zip)

What’s inside

1. **APO**: SymbolProbe → WiringSynth → ProofForge → AdmissionSim. Outputs `.apo/rtt.manifest.json`, `attestation.json`, and an event envelope.
2. **Agent Mesh (NATS)**: CloudEvents-style MCP envelopes. SPIFFE header check stub.
3. **Graph store (Neo4j)**: ingests `rtt.manifest.json` into a Plan↔Tool graph.
4. **OpenFeature**: flags file and Rollouts example.
5. **Single-host**: three systemd units and FHS scaffolding.
6. **Adapters**: Postgres, SQLite, and Qdrant MCP servers.
7. **Agents**: safety rule stub and budget cutoff agent.
8. **WASM SDK**: host and guest stubs for in-process redaction/coercion.

Run core deps

```bash
docker compose -f docker-compose.dev.yaml up -d   # NATS + Neo4j
```

APO test

```bash
cd apo && npm i && npm run dev
# outputs .apo/rtt.manifest.json and attestation.json in your SCAN_ROOT
```

Mesh test

```bash
cd agent-mesh && npm i && npm run dev
# publishes heartbeat events to NATS subject mcp.events
```

Graph ingest

```bash
cd mcp-graph && npm i && npm run dev
# scans SCAN_ROOT for rtt.manifest.json and writes nodes/edges to Neo4j
```

Adapters

```bash
# Postgres
cd adapters/db-postgres && npm i && PG_URI=postgres://... npm run dev
# SQLite
cd adapters/db-sqlite && npm i && SQLITE_PATH=/tmp/mcp.sqlite npm run dev
# Qdrant
cd adapters/vector-qdrant && npm i && QDRANT_URL=http://localhost:6333 npm run dev
```

Next wiring

* Emit APO envelopes on `mcp.events`. Subscribe with safety, cost, and rollout agents.
* Add SPIRE mTLS and sign envelopes. Enforce OPA decisions before rollout.
* Extend OpenFeature into your gateway so `plan.canaryWeight` drives traffic weights.
* Replace WASM stubs with a proper ABI and run filters in the gateway request path.

This covers the eight steps with runnable scaffolds and leaves room for quick-connect flexibility.
---end---