---begin---
Delivered. Drop in and run.

* [mcp_control_plane_bundle.zip](sandbox:/mnt/data/mcp_control_plane_bundle.zip)

What you gained

* **SPIRE chart**: trust domain, server StatefulSet, agent DaemonSet, k8s_psat. Bootstrap secret placeholder.
* **Vault baseline**: Job to enable k8s auth + role, ExternalSecrets wiring, ClusterSecretStore.
* **Nexus chart**: stateful registry with PVC.
* **CAS+FUSE**: privileged DaemonSet that mounts `/mnt/relay`. Stub container to be replaced by real FUSE.
* **Argo CD app-of-apps**: project and Applications for spire, vault-baseline, nexus, cas-vfs.

How it connects

* SPIRE issues SVIDs to workloads. Use SVIDs for mTLS and policy.
* Vault uses k8s auth tied to the gateway SA. External Secrets syncs provider keys to k8s Secrets.
* Nexus stores MCP artifacts, signed plans, plugins, and SBOMs.
* CAS-VFS mounts node-local `/mnt/relay` as the low-latency path for RTT manifests and blobs.
* Argo CD pulls each chart from Git and reconciles continuously.

Next actions

1. **Pin images and TLS**. Provide CA bootstrap secret for SPIRE. Terminate Vault root token use.
2. **Replace CAS stub**. Swap `cas-vfsd` with a real FUSE daemon or s3fs/juicefs while your own FUSE evolves.
3. **Wire budgets and SLOs to admission**. Gatekeeper + OPA bundle that checks tenant budget and residency on every rollout.
4. **Register workloads**. Add SPIRE registration entries for your namespaces and label selectors.
5. **Argo sources**. Point `repoURL` and `path` to your Git. Split environments via AppProjects.

Optional adds

* Gatekeeper constraint templates for plan invariants.
* External Secrets for Anthropic, OpenRouter, TURN creds.
* Tempo/Jaeger and Prometheus stack.
* Envoy/Caddy ingress with mTLS and QUIC.

If you want, I can add Gatekeeper templates for plan invariants and a minimal SPIRE registration CR next.
---end---