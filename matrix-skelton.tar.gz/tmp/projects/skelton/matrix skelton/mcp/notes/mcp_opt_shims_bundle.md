---
title: MCP Opt Shims Bundle
deprecated: false
---
# MCP Opt Shims Bundle

Download. Drop in and wire.

* [mcp_opt_shims_bundle.zip](sandbox:/mnt/data/mcp_opt_shims_bundle.zip)

What you got

* `/usr/bin` shims

  * `mcp-shim`: resolves tools to `/opt/mcp/<pkg>@<digest>/bin/<tool>`.
    Order: `MCP_TOOL_BIN_<TOOL>` → `MCP_PLAN_BIN` (colon list) → `~/.mcp/aliases.d/<tool>` → **dev-only** `/opt/mcp/current/<tool>/bin/<tool>`.
    Set `MCP_VERIFY_DIGEST=1` in prod to reject non-digest paths.
  * Wrappers: `node`, `python`, `claude-flow` → all call `mcp-shim`.
* Home layout skeleton `~/.mcp`

  * `aliases.d/` for local per-user overrides (executables or symlinks).
  * `flags/flags.json` for OpenFeature flag defaults.
  * `cache/`, `logs/`. No secrets.
* Gatekeeper chart `gatekeeper-planbins`

  * Require envs: `PLAN_BIN_DIR`, `MCP_PLAN_BIN`.
  * Forbid `/opt/mcp/current` in env or mounts.
  * Require annotation `rtt.opt/digests` with one or more sha256 digests.

Use

```bash
# Install the chart
helm upgrade --install gk-planbins charts/gatekeeper-planbins -n gatekeeper-system

# In your Deployment
spec:
  template:
    metadata:
      annotations:
        rtt.opt/digests: "7b1c...c0a9, 9e3f...12ab"
    spec:
      containers:
      - name: gw
        env:
        - name: MCP_PLAN_BIN
          value: "/opt/mcp/node@sha256:7b1c.../bin:/opt/mcp/claude-flow@sha256:9e3f.../bin"
        - name: MCP_VERIFY_DIGEST
          value: "1"
```

Dev helper

```bash
# Quick toggle (dev only; Gatekeeper blocks in prod)
sudo /opt/update-current.sh node node "sha256:7b1c..."
```

Result

* No global installs.
* Every CLI pinned by digest.
* Gatekeeper blocks tag-based or “current” paths.
* Users can test via `~/.mcp/aliases.d` without touching system state.
--- END OF FILE ---