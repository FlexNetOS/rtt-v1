Download. Drop in and run.

* [model_gateway_ui_bundle.zip](sandbox:/mnt/data/model_gateway_ui_bundle.zip)

## What you got

* **Model Gateway**

  * OpenAI-compatible `/v1/chat/completions`.
  * Routes to OpenRouter/LiteLLM, Anthropic, or local `llama.cpp` server.
  * Per-tenant caps: output tokens and request USD estimate.
  * Fail-fast policy check before calling providers.
  * Simple stats endpoint `/api/stats` for UI.

* **RTT UI dashboard**

  * Minimal React + Vite.
  * Shows request counters and placeholders for plans, lanes, budgets.
  * Proxies `/api/*` to the gateway during dev.

* **Helm charts**

  * `charts/gateway`: deploys the gateway with secret for OpenRouter API key.
  * `charts/ui`: deploys the dashboard service.

## Local quick start

```bash
# Gateway
cd model-gateway
npm i
npm run build
OPENROUTER_API_KEY=... node dist/index.js

# UI
cd ../ui-dashboard
npm i
npm run dev  # http://localhost:5173
```

## K8s

```bash
helm upgrade --install gateway charts/gateway -n rtt --create-namespace \
  --set image.repository=ghcr.io/yourorg/model-gateway --set image.tag=latest

helm upgrade --install rtt-ui charts/ui -n rtt --create-namespace \
  --set image.repository=ghcr.io/yourorg/rtt-ui --set image.tag=latest
```

## Wiring to RTT

* Treat the gateway as the **model provider** behind your RTT planner.
* Export an RTT manifest for model.chat alias `chat-default`.
* Plans place agents next to `llama.cpp` when SHM is available.
* Admission control stays in your ILP solver; the gateway enforces per-request caps.

## Next upgrades

* Add OTel GenAI spans in the gateway.
* Add structured-output coercion and JSON-Schema checks on responses.
* Integrate realtime lane: WebRTC ingress with TURN for remote calls.
* Expand UI with plan diffs, OPA decisions, and trace links.
