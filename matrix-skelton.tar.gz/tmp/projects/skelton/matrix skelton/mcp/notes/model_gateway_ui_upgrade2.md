Delivered. Drop in and run.

* [model_gateway_ui_upgrade2.zip](sandbox:/mnt/data/model_gateway_ui_upgrade2.zip)

What you get

1. **SSE streaming** for `/v1/chat/completions`.

   * Request body flag: `"stream": true`.
   * Transparent pass-through for OpenAI-compatible, Anthropic, and llama.cpp.
   * Final `[DONE]` sent by gateway.

2. **GenAI spans + token budgets**.

   * Spans: `genai.chat.request`, `genai.chat.route`, provider spans.
   * Attributes: `gen_ai.usage.prompt_tokens`, `gen_ai.usage.completion_tokens`, `gen_ai.cost.estimated_usd`.
   * OTLP gRPC export via `OTEL_EXPORTER_OTLP_ENDPOINT`.
   * Per-tenant accounting: tokens in/out and spend in USD.

3. **Per-tenant ring buffers + cost UI**.

   * Endpoints: `/api/tenants`, `/api/tenants/:id`.
   * UI tables show budgets, cumulative spend, and last N requests with trace links.

How to run

```bash
# Gateway
cd model-gateway
npm i
npm run build
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317 \
OTEL_SERVICE_NAME=model-gateway \
OPENROUTER_API_KEY=... \
node --require ./dist/otel-preload.js dist/index.js

# UI
cd ../ui-dashboard
npm i
VITE_APM_BASE="https://your-apm/trace/" npm run dev
```

Test SSE

```bash
curl -N http://localhost:8080/v1/chat/completions \
  -H 'content-type: application/json' \
  -d '{"model":"chat-default","messages":[{"role":"user","content":"hello"}],"stream":true}'
```

Notes

* Structured output validation still works on non-streaming calls. Streaming is pass-through; usage is captured from final SSE if present.
* Tenants default to `public`. Set per-tenant budgets in your orchestrator and pass `tenant` in the request.
* Wire OTel Collector to your backend. The UI lists recent trace IDs; set `VITE_APM_BASE` to your viewer URL.
