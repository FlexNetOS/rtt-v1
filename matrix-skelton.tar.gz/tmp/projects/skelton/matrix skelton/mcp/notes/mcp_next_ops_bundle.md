Delivered. Wire these five upgrades.

* [mcp_next_ops_bundle.zip](sandbox:/mnt/data/mcp_next_ops_bundle.zip)

# 1) Kube apply path from `mcp.rollouts` → Argo

Two modes in `services/rollout-applier`:

* Webhook:

  ```bash
  cd services/rollout-applier && npm i
  NATS_URL=nats://127.0.0.1:4222 \
  APPLY_MODE=webhook \
  ARGOCD_WEBHOOK_URL=https://argocd.example.com/api/webhook/promote \
  OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317 \
  npm run dev
  ```

  Subscribes to JetStream `mcp.rollouts` durable `rollouts`. On `rollout.allow`, POSTs `{plan_id, action, weight}` to your Argo/CD webhook. Replace URL with your handler that bumps canary weight or flips OpenFeature flags.

* GitOps PR:

  ```bash
  APPLY_MODE=gitops GITOPS_REPO=/path/to/checked-out/repo npm run dev
  ```

  Creates branch `rollout/<plan_id>`, writes a flag patch under `flags/`, commits, and pushes. Your GitOps controller promotes upon merge.

# 2) End-to-end OTel spans and tracecontext

* Library `@mcp/tracecontext` initializes an SDK and handles W3C tracecontext.
* `rollout-applier` extracts `traceparent` from NATS headers and starts span `rollout.apply`.
* Use the same lib in APO and your gateway to inject headers on publish and extract on consume. Propagate via NATS headers:

  ```ts
  import { injectToHeaders } from "@mcp/tracecontext";
  const h = new Headers(); injectToHeaders(h);
  nc.publish("mcp.events", sc.encode(JSON.stringify(env)), { headers: h });
  ```

# 3) JetStream retries and DLQ

* Bootstrap:

  ```bash
  node jetstream/bootstrap.js
  ```

  Creates stream `MCP`, subject `mcp.*`, durable consumer `rollouts` with `max_deliver: 5`. Messages `nak()` retry. Exhausted go to DLQ subject `dlq.*`. Use `jsm.consumers.add` to attach a DLQ deliver subject in prod.

# 4) OPA policy bundle (beyond `allow`)

* Folder `opa-bundle/` includes:

  * `policy/plan_invariants.rego`: budget, residency, immutability hooks.
  * `policy/providers.rego`: provider allowlist backed by `data.json`.
  * `.manifest` for OPA bundles.
* Serve as a bundle or mount into OPA:

  ```bash
  opa run --server --addr :8181 --bundle ./opa-bundle
  ```
* Query:

  ```
  POST /v1/data/rtt/allow  { "input": <plan> }
  ```

# 5) WASM host pooling

* Package `wasm-pool` implements a prewarmed pool of instances and round-robin acquire.
* ABI v1: `{ memory, alloc, free, transform }`. Compile your guest to `wasm-pool/guest/redact.wasm`.
* Demo:

  ```bash
  cd wasm-pool && npm i
  # place guest/redact.wasm
  npm run dev
  ```

# Operational wiring

* APO → publish signed `mcp.apo.plan` with `traceparent` header.
* Rollout agent → verify + OPA check → publish `mcp.rollouts` with propagated `traceparent`.
* `rollout-applier` → consumes via JetStream with retries, applies promotion via webhook or GitOps.
* Gateway → reads OpenFeature flags and routes traffic; run WASM pool filters pre-egress and post-ingress.
* OTel → traces visible across APO → rollout → applier → gateway.

# What remains

* How can we replace webhook stub with actual Argo CD or Argo Rollouts API calls and keep flexibility vendor-agnostic, easy to reason about. We want adaptive. 
* Add DLQ consumer and alerting.
* Expand OPA bundle for schema coercion requirements and provider-specific safety policies.
* Add SPIRE-based mTLS for NATS and H2C→mTLS upgrade at ingress.
* Harden WASM host for production use (streaming, timeouts, memory limits).