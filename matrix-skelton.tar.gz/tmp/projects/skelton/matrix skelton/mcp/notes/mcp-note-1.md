---
title: MCP and RTT filesystem and operational layout
deprecated: false
---
# MCP and RTT filesystem and operational layout

Mapping first, reasons after.

| Part                                                      | RTT                                                                                 | MCP                                                                           | Why                                                                                                                  |
| --------------------------------------------------------- | ----------------------------------------------------------------------------------- | ----------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| 1) “Global” apps (e.g., Node.js, Claude Code/Claude Flow) | **Used** via version-pinned tool shims or OCI images selected by the plan           | **Provisioned** and **governed** (signing, policy, rollout)                   | Keep runtime reproducible. Plans pick exact versions; control-plane owns install, trust, and upgrades.               |
| 2) `/usr` and Home                                        | `/usr` is read-only in RTT; Home holds per-user caches only                         | `/usr` minimally used by base OS; user secrets live in Vault, not Home        | Limit drift. Per-user overrides are allowed, but not trusted for plans or credentials.                               |
| 3) `/opt`                                                 | **Primary execution tree** for providers, agents, models, adapters (read-only bind) | **Staging** and **publishing** of signed bundles to `/opt/mcp/<pkg>@<digest>` | `/opt` cleanly hosts vendor bits without polluting system paths; content-addressable prevents “works on my machine.” |
| 4/6) `tmp`                                                | Short-lived buffers, redaction/coercion scratch; tmpfs preferred                    | Same; control quotas and scrubbing                                            | Ephemeral only. Never persist artifacts or secrets.                                                                  |
| 5) Backups                                                | Not needed for ephemeral RTT state                                                  | **Yes** for plans, policies, Nexus/registry, CAS, DBs, traces                 | Control-plane is your source of truth. Snapshot and encrypt.                                                         |
| 7) Docs (reports, audits, cookbook, wiki)                 | **Consumed** at runtime (help, SOPs, prompts)                                       | **Authored, versioned, signed**; indexed into the graph                       | Treat docs as code. Tie every rollout/audit to a doc hash.                                                           |

Details and how to wire each.

1. “Global” applications (Node.js, Claude Code/Flow)

* Best practice: **no global installs**.

  * MCP: build OCI images or signed tarballs into `/opt/mcp/<name>@<digest>`. Track SBOM + provenance.
  * RTT: plans **reference digest** and invoke via shims:

    * `/usr/bin/node` → shim reading `PLAN_BIN_DIR` → `/opt/mcp/node@sha256:…/bin/node`.
    * Claude Code/Flow exposed as an **MCP tool** with JSON-Schema contracts; mounted from `/opt/mcp/claude-flow@…`.
* Multi-provider agent reuse: keep shared agents in `/.agents` and expose provider overlays through **symlinks/bind-mounts**. Plans target the shared agent ID; provider adapters supply dialect specifics.
* Have we addressed this? **Partially.** We defined `/opt` layout, agent overlays, and shims. To complete: remove any remaining `npm i -g` and replace with pinned bundles + shims + policy checks.

2. `/usr` and Home

* `/usr`: read-only. Only tiny **wrappers** and manpages. No mutable libs.
* Home (`/home/$USER`):

  * Allowed: local caches (`~/.mcp/cache`, model prompts cache), editor settings, UI preferences.
  * Disallowed: secrets, plan files, production configs. Use Vault/ExternalSecrets; fetch per-workload via SPIRE identity.

3. `/opt`

* Structure:

  ```
  /opt/mcp/<pkg>@<digest>/bin … lib … schema …
  /opt/mcp/.index/        # CAS & plan index (read-only at runtime)
  ```
* MCP publishes to `/opt` only after: sign → attest → policy pass → canary pass.
* RTT bind-mounts `/opt` **read-only** into workloads. Plan contains the exact digest, not a tag.

4/6) `tmp`

* Use `tmpfs` with `noexec,nodev,nosuid`.
* Enforce size limits and TTL.
* WASM and model filters write scratch here, then **zeroize** on close. No PII persistence.

5. Backups

* Scope: Postgres (plans, policies, budgets, audit), Nexus, CAS blobstore, trace store, graph DB.
* Method: encrypted, immutable snapshots + object-lock.
* Tie snapshots to **plan hashes** so any release can be fully reconstructed.

7. Docs: reports, audits, cookbook, wiki

* Store in Git or a docs repo. MCP **ingests** and signs doc sets; adds them to the knowledge graph.
* RTT can surface inline help and SOP steps by **doc hash**.
* Audits reference: plan hash ↔ doc hash ↔ attestation set.

Operational guardrails

* **SPIRE everywhere**. Workloads fetch SVIDs; NATS/Envoy use mTLS with SPIRE bundles.
* **Gatekeeper invariants**: required annotations (`rtt.plan/hash`, `…/signed`, `…/providers`), pinned image digests, residency.
* **OPA bundle**: schema-coercion required for structured outputs; provider safety rules for PII lanes.

WASM host hardening (RTT)

* Pool prewarmed instances.
* Timeouts, output byte caps, fixed memory pages.
* Streaming ABI for large payloads.
* Deterministic mode for schema-coercion filters.

Final placement cheatsheet

* **RTT only**: tmp buffers, WASM filter runtime, SHM/UDS lanes.
* **MCP only**: backups, policies, registries, provenance, rollouts, budgets.
* **Both**: `/opt` (publish in MCP, execute in RTT), docs (authored in MCP, referenced in RTT), adapters/tools (governed in MCP, invoked in RTT).

If you want, I can add the `/opt` shim scripts, a `~/.mcp` minimal layout, and the Gatekeeper rule to block tag-based binaries next.
--- --- IGNORE ---