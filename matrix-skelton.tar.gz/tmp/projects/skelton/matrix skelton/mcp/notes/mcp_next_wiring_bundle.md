---
Delivered. Wire these in order.

* [mcp_next_wiring_bundle.zip](sandbox:/mnt/data/mcp_next_wiring_bundle.zip)

# 1) Emit APO envelopes on `mcp.events`

* Build and run:

  ```bash
  (cd libs/envelope && npm i && npm run build)
  (cd apo && npm i && SPIFFE_ID="spiffe://example.org/ns/rtt/sa/apo" \
    SIGN_KID=apo-dev SIGN_SK_B64=<ed25519-secret-base64> \
    NATS_URL=nats://127.0.0.1:4222 npm run dev)
  ```
* Output: `.apo/rtt.manifest.json`, `attestation.json`, and a signed CloudEvent published to NATS with header `x-spiffe-id`.

# 2) SPIRE mTLS + signed envelopes + OPA before rollout

* Envelopes: Ed25519 sign/verify via `@mcp/envelope`:

  * `sign(env, SIGN_SK_B64, kid)` adds `extensions.sig` and `extensions.kid`.
  * Rollout agent verifies with `SIGN_PK_B64`.
* NATS TLS using SPIRE SVIDs:

  * Fetch certs from spire-agent. Start NATS with `--tls`.
  * Clients pass `NATS_CERT`, `NATS_KEY`, `NATS_CA` (see `nats-tls/README.md`).
* OPA enforcement:

  ```bash
  (cd agents/rollout && npm i && OPA_URL=http://opa:8181 \
     SIGN_PK_B64=<ed25519-public-base64> NATS_URL=nats://127.0.0.1:4222 npm run dev)
  ```

  * Subscribes to `mcp.events`, verifies signature, calls OPA `rtt/allow`, emits `mcp.rollouts` with `rollout.allow|rollout.block`.

# 3) OpenFeature drives traffic weights

* Patch your gateway’s route picker to honor `plan.canaryWeight` from a flag file. See `gateway-openfeature/README.md` and `flag-runtime.ts`.
* Provide two routes under the same alias (`chat-default`) where one is the canary. Weight chosen by the flag.
* Manage flags via ConfigMap or any OpenFeature provider in prod. Argo Rollouts example is included in earlier bundles.

# 4) WASM filters in the gateway path

* ABI v1 documented in `wasm-abi/ABI.md`. Host loader in `wasm-abi/host/index.js`. Rust guest example provided.
* Use case: run redaction and JSON coercion on request/response in-process before egress to a model provider.
* Integration points:

  * Pre-egress: redact PII from prompts.
  * Post-ingress: coerce/validate structured outputs.

# Rollout wiring loop

1. APO publishes a signed `mcp.apo.plan`.
2. Rollout agent verifies → queries OPA → emits `mcp.rollouts`.
3. Your CD layer consumes `mcp.rollouts` and applies Argo Rollouts or flips OpenFeature flags.
4. Telemetry agents monitor SLOs and budgets, feed back weight changes.

# Notes and caveats

* Replace the placeholder NATS TLS call in APO with actual TLS options once SVID paths are wired. Use Node NATS client `tls: { certFile, keyFile, caFile }`.
* Keep key material out of images. Load Ed25519 keys from Vault or SPIRE workload API.
* The WASM guest uses a simple alloc/free demo. Swap to a stable ABI or WASI if you need streams.

# What remains open

* Full kube apply path from `mcp.rollouts` to Argo (Webhook or GitOps PR).
* End-to-end OTel spans around APO → rollout → gateway.
* Retry and dead-letter subjects in NATS (JetStream).
* Comprehensive policy bundles for OPA beyond `allow`.
* Performance hardening of the WASM host with pooling.

This delivers the four requested upgrades with signed events, policy gating, flag-driven traffic, and inline WASM filters.
---end---