Delivered. Drop in and run.

* [model_gateway_ui_upgrade.zip](sandbox:/mnt/data/model_gateway_ui_upgrade.zip)

What changed

1. OTel GenAI spans in the gateway.

   * Manual tracer with OTLP gRPC exporter.
   * Spans: `genai.chat.request`, `genai.chat.route`, and per-provider spans.
   * Attributes set: `gen_ai.system`, `gen_ai.request.model`, `gen_ai.request.max_tokens`, `gen_ai.response.finish_reasons`.
   * `x-trace-id` header on responses. In-memory `/api/traces` for the UI.

2. Structured-output coercion + JSON-Schema checks.

   * Request fields: `response_schema` and `coerce` (optional).
   * Extracts JSON from assistant text (direct, fenced code, or brace slice).
   * Validates with Ajv. Replaces assistant message content with validated JSON.

3. Realtime lane with TURN.

   * POST `/realtime/offer` accepts SDP offer. Uses `wrtc` to create an answer.
   * DataChannel named by the client sends OpenAI-style chat payloads. Replies carry gateway completions.
   * `ICE_SERVERS` env supports STUN/TURN JSON. Works with your coturn.

4. UI expansion.

   * Plan diff panel compares `/rtt/plans/latest.json` vs `/rtt/plans/last_applied.json`.
   * OPA decisions test panel calls `/api/opa/decide`.
   * Trace links panel lists recent trace IDs; set `VITE_APM_BASE` to your viewer base.

How to run

```bash
# Gateway
cd model-gateway
npm i
npm run build
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317 \
OTEL_SERVICE_NAME=model-gateway \
OPENROUTER_API_KEY=... \
node --require ./dist/otel-preload.js dist/index.js

# UI
cd ../ui-dashboard
npm i
VITE_APM_BASE="https://your-apm/trace/" npm run dev
```

K8s wiring

* Point gateway Pod at your OTel Collector with `OTEL_EXPORTER_OTLP_ENDPOINT`.
* Expose `/realtime/offer` through Caddy. Keep media relay on coturn.
* Mount `/rtt/plans/` into UI Pod if you want live plan diffs, or proxy those files via a small sidecar.

Next options

* Add streaming SSE for `/v1/chat/completions`.
* Push GenAI spans to OTel with full token metrics and budgets.
* Add per-tenant ring buffers and cost reports to the UI.
