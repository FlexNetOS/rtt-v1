---
Download. Apply after Gatekeeper and SPIRE.

* [mcp_policy_identity_addon.zip](sandbox:/mnt/data/mcp_policy_identity_addon.zip)

Contents

* Gatekeeper invariants chart

  * Templates: required plan annotations + immutability, allowed providers, residency by namespace label, image-by-digest.
  * Synces Namespaces so Rego can read `rtt.allowed-regions`.
  * Constraints pre-wired for Deployments.

* SPIRE registration CRs

  * `ClusterSPIFFEID` example with `podSelector` and `namespaceSelector`.
  * `SPIFFEID` namespaced example for a single workload.

Apply

```bash
# Gatekeeper invariants
helm upgrade --install gk-invariants charts/gatekeeper-invariants -n gatekeeper-system

# Choose one SPIRE CR depending on your controller:
kubectl apply -f spire/cluster-spiffeid.yaml   # cluster-scoped
# or
kubectl apply -f spire/spiffeid.yaml           # namespaced
```

Wire-up requirements

* Add required annotations on every workload created by MCP/RTT:

  * `rtt.plan/hash`, `rtt.plan/signed`, `rtt.plan/id`, `rtt.data/region`.
  * `rtt.plan/providers` as CSV of upstream vendors.
* Label namespaces with allowed residency:

  * `kubectl label ns rtt rtt.allowed-regions=us-east1,us-central1`
* Ship container images pinned by digest. Constraint blocks tag-only images.

Result

* Plans cannot change post-admission.
* Only approved providers get through.
* Region residency enforced at the namespace.
* Images must be by digest.
* SPIRE issues SVIDs to your gateway pods through label selectors.

---end---
